<?php

namespace App\Models;

use CodeIgniter\Model;

class LaboratoryModel extends Model
{
    protected $table = 'laboratories';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'room', 'pic_name', 'pic_email', 'pic_phone', 'image'];
}
