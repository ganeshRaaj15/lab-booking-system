<?= $this->extend('layouts/main_user') ?>
<?= $this->section('content') ?>

<style>
/* ============================================================
   LABORATORY PAGE - COHESIVE WITH HOMEPAGE DESIGN
   ============================================================ */
.lab-page {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    min-height: 100vh;
    padding-top: 60px;
}

/* Hero Header - Adjusted to sit closer to navbar */
.lab-hero {
    background: linear-gradient(135deg, #1e40af, #3b82f6);
    padding: 40px 0 50px;
    color: white;
    border-radius: 0 0 32px 32px;
    margin-bottom: 50px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.2);
    position: relative;
    overflow: hidden;
}

.lab-hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,70 Q250,20 500,70 T1000,70 L1000,100 L0,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
    background-size: cover;
}

.hero-content {
    position: relative;
    z-index: 1;
}

.lab-title {
    font-size: 2.8rem;
    font-weight: 900;
    margin-bottom: 15px;
    text-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    background: linear-gradient(135deg, #ffffff, #e0e7ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.lab-subtitle {
    font-size: 1.15rem;
    color: rgba(255, 255, 255, 0.9);
    max-width: 600px;
    margin: 0 auto 25px;
    line-height: 1.6;
}

/* Search Box */
.lab-search-box {
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    max-width: 600px;
    margin: 0 auto;
    transition: all 0.3s ease;
}

.lab-search-box:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
}

.search-input {
    background: white;
    border: none;
    border-radius: 12px;
    padding: 15px 20px;
    font-size: 1rem;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}

.search-input:focus {
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
    border-color: #3b82f6;
}

.search-btn {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    border: none;
    border-radius: 12px;
    padding: 15px 25px;
    color: white;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}

.search-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.6);
    background: linear-gradient(135deg, #2563eb, #1e40af);
}

.search-btn i {
    transition: transform 0.3s ease;
}

.search-btn:hover i {
    transform: scale(1.2);
}

/* Search Indicator */
.search-indicator {
    text-align: center;
    margin-top: 10px;
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.9rem;
    min-height: 24px;
}

/* Search Results Alert */
.search-alert {
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
    border: none;
    border-radius: 16px;
    border-left: 4px solid #3b82f6;
    padding: 20px;
    margin-bottom: 40px;
    box-shadow: 0 8px 25px rgba(30, 64, 175, 0.08);
}

.search-alert a {
    color: #1e40af;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
}

.search-alert a:hover {
    color: #3b82f6;
    text-decoration: underline;
}

/* Lab Cards */
.lab-card {
    background: white;
    border-radius: 24px;
    overflow: hidden;
    border: 1px solid #e2e8f0;
    transition: all 0.4s ease;
    height: 100%;
    position: relative;
    box-shadow: 0 10px 30px rgba(30, 64, 175, 0.05);
}

.lab-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.lab-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 60px rgba(30, 64, 175, 0.12);
    border-color: #3b82f6;
}

.lab-card-img {
    height: 200px;
    object-fit: cover;
    width: 100%;
    transition: transform 0.5s ease;
}

.lab-card:hover .lab-card-img {
    transform: scale(1.05);
}

.lab-placeholder {
    height: 200px;
    background: linear-gradient(135deg, #e0f2fe, #eff6ff);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3.5rem;
    color: #3b82f6;
    transition: all 0.3s ease;
}

.lab-card:hover .lab-placeholder {
    background: linear-gradient(135deg, #dbeafe, #e0f2fe);
    color: #1e40af;
}

.lab-card-content {
    padding: 25px;
}

.lab-name {
    color: #1e293b;
    font-weight: 700;
    font-size: 1.3rem;
    margin-bottom: 15px;
    line-height: 1.4;
}

.lab-details {
    margin-bottom: 20px;
}

.lab-detail {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #64748b;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.lab-detail i {
    color: #3b82f6;
    width: 18px;
    text-align: center;
}

.lab-pic {
    background: #eff6ff;
    padding: 8px 15px;
    border-radius: 50px;
    margin-top: 15px;
    display: inline-block;
}

.lab-pic-label {
    color: #3b82f6;
    font-size: 0.85rem;
    font-weight: 500;
}

.lab-pic-name {
    color: #1e40af;
    font-weight: 600;
    font-size: 0.9rem;
    margin-left: 5px;
}

.lab-card-footer {
    padding: 20px 25px 25px;
    border-top: 1px solid #f1f5f9;
    display: flex;
    justify-content: flex-end;
}

.view-btn {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    border: none;
    border-radius: 12px;
    padding: 10px 24px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}

.view-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.6);
    color: white;
}

/* No Results Section */
.no-results {
    background: white;
    border-radius: 24px;
    padding: 60px 40px;
    text-align: center;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    max-width: 500px;
    margin: 0 auto;
}

.no-results-icon {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    color: #3b82f6;
    font-size: 2.5rem;
}

.no-results h4 {
    color: #1e40af;
    font-weight: 700;
    margin-bottom: 10px;
}

.no-results p {
    color: #64748b;
    margin-bottom: 25px;
}

.clear-search-btn {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    border: none;
    border-radius: 12px;
    padding: 12px 30px;
    font-weight: 600;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}

.clear-search-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.6);
    color: white;
}

/* Counter Badge */
.lab-count {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    padding: 8px 20px;
    border-radius: 50px;
    font-weight: 600;
    display: inline-block;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}

/* Hidden Labs */
.lab-hidden {
    display: none !important;
}

/* Loading Animation */
.loading-spinner {
    display: none;
    width: 40px;
    height: 40px;
    border: 3px solid rgba(59, 130, 246, 0.3);
    border-radius: 50%;
    border-top-color: #3b82f6;
    animation: spin 1s ease-in-out infinite;
    margin: 0 auto 20px;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Responsive Design */
@media (max-width: 768px) {
    .lab-page {
        padding-top: 50px;
    }
    
    .lab-hero {
        padding: 30px 0 40px;
    }
    
    .lab-title {
        font-size: 2.2rem;
    }
    
    .lab-subtitle {
        font-size: 1rem;
    }
    
    .lab-search-box {
        padding: 15px;
    }
    
    .search-input,
    .search-btn {
        padding: 12px 15px;
    }
    
    .lab-card-content {
        padding: 20px;
    }
    
    .lab-card-footer {
        padding: 15px 20px 20px;
    }
}
</style>


<!-- ============================================================
     LABORATORY PAGE CONTENT
     ============================================================ -->
<div class="lab-page">
    
    <!-- HERO SECTION - Now positioned closer to navbar -->
    <section class="lab-hero">
        <div class="container">
            <div class="hero-content text-center">
                <h1 class="lab-title">FKMP Laboratory Directory</h1>
                <p class="lab-subtitle">
                    Explore our state-of-the-art laboratories and begin your equipment booking journey.
                    Discover facilities designed for innovation and research excellence.
                </p>

                <!-- Search Box -->
                <div class="lab-search-box">
                    <form method="get" class="d-flex gap-3" id="searchForm">
                        <input type="text"
                               name="q"
                               id="searchInput"
                               value="<?= esc($search ?? '') ?>"
                               class="form-control search-input"
                               placeholder="Search laboratories by name, room, or PIC..."
                               autocomplete="off">

                        <button type="submit" class="btn search-btn">
                            <i class="bi bi-search me-2"></i>
                            Search
                        </button>
                    </form>
                    <!-- Search Indicator -->
                    <div class="search-indicator" id="searchIndicator">
                        <?php if (!empty($search)): ?>
                            <span>Showing results for: <strong><?= esc($search) ?></strong></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="container pb-5">
        
        <!-- Laboratory Count -->
        <div class="text-center">
            <span class="lab-count" id="labCount">
                <i class="bi bi-building me-2"></i>
                <?= count($labs) ?> <?= count($labs) === 1 ? 'Laboratory' : 'Laboratories' ?> Available
            </span>
        </div>

        <!-- Loading Spinner -->
        <div class="loading-spinner" id="loadingSpinner"></div>

        <!-- If no labs found (Initially hidden) -->
        <div class="no-results" id="noResults" style="display: <?= empty($labs) ? 'block' : 'none' ?>;">
            <div class="no-results-icon">
                <i class="bi bi-buildings"></i>
            </div>
            <h4 class="fw-semibold">No laboratories found</h4>
            <p class="text-muted" id="noResultsText">Try adjusting your search keywords or browse all available laboratories.</p>
            
            <button id="clearFilterBtn" class="clear-search-btn" style="display: <?= !empty($search) ? 'inline-flex' : 'none' ?>;">
                <i class="bi bi-arrow-left me-1"></i>
                View All Laboratories
            </button>
        </div>

        <!-- Laboratories Grid -->
        <div class="row g-4" id="labsGrid">
            <?php foreach ($labs as $lab): ?>
                <div class="col-md-6 col-lg-4 lab-item" 
                     data-name="<?= esc(strtolower($lab['name'])) ?>"
                     data-room="<?= esc(strtolower($lab['room'] ?? '')) ?>"
                     data-pic="<?= esc(strtolower($lab['pic_name'] ?? '')) ?>"
                     data-capacity="<?= esc($lab['capacity'] ?? '') ?>">
                    <div class="lab-card">
                        
                        <!-- Laboratory Image -->
                        <?php if (!empty($lab['image'])): ?>
                            <img src="<?= esc($lab['image']) ?>"
                                 alt="<?= esc($lab['name']) ?>"
                                 class="lab-card-img">
                        <?php else: ?>
                            <div class="lab-placeholder">
                                <i class="bi bi-building"></i>
                            </div>
                        <?php endif; ?>

                        <!-- Laboratory Content -->
                        <div class="lab-card-content">
                            <h5 class="lab-name"><?= esc($lab['name']) ?></h5>
                            
                            <div class="lab-details">
                                <?php if (!empty($lab['room'])): ?>
                                    <div class="lab-detail">
                                        <i class="bi bi-door-open"></i>
                                        <span>Room <?= esc($lab['room']) ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($lab['capacity'])): ?>
                                    <div class="lab-detail">
                                        <i class="bi bi-people"></i>
                                        <span>Capacity: <?= esc($lab['capacity']) ?> people</span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($lab['equipment_count'])): ?>
                                    <div class="lab-detail">
                                        <i class="bi bi-tools"></i>
                                        <span><?= esc($lab['equipment_count']) ?> equipment available</span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Person in Charge -->
                            <?php if (!empty($lab['pic_name'])): ?>
                                <div class="lab-pic">
                                    <span class="lab-pic-label">Person in Charge:</span>
                                    <span class="lab-pic-name"><?= esc($lab['pic_name']) ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Footer with Action Button -->
                        <div class="lab-card-footer">
                            <a href="<?= site_url('/laboratories/' . $lab['id']) ?>"
                               class="btn view-btn">
                                <i class="bi bi-eye me-1"></i> View Details & Book
                            </a>
                        </div>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>

</div>

<script>
// Real-time search filtering
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const labsGrid = document.getElementById('labsGrid');
    const labItems = document.querySelectorAll('.lab-item');
    const labCount = document.getElementById('labCount');
    const noResults = document.getElementById('noResults');
    const noResultsText = document.getElementById('noResultsText');
    const clearFilterBtn = document.getElementById('clearFilterBtn');
    const searchIndicator = document.getElementById('searchIndicator');
    const loadingSpinner = document.getElementById('loadingSpinner');
    
    let filterTimeout;
    let isFiltering = false;

    // Function to filter labs
    function filterLabs(searchTerm) {
        isFiltering = true;
        loadingSpinner.style.display = 'block';
        
        // Hide all labs initially
        labItems.forEach(item => {
            item.classList.add('lab-hidden');
        });
        
        // Show matching labs
        let visibleCount = 0;
        labItems.forEach(item => {
            const name = item.dataset.name || '';
            const room = item.dataset.room || '';
            const pic = item.dataset.pic || '';
            const capacity = item.dataset.capacity || '';
            
            const searchLower = searchTerm.toLowerCase();
            const matches = name.includes(searchLower) || 
                          room.includes(searchLower) || 
                          pic.includes(searchLower) ||
                          capacity.includes(searchTerm);
            
            if (matches || searchTerm === '') {
                item.classList.remove('lab-hidden');
                visibleCount++;
            }
        });
        
        // Update count and show/hide no results
        setTimeout(() => {
            updateResults(visibleCount, searchTerm);
            isFiltering = false;
            loadingSpinner.style.display = 'none';
            
            // Animate visible cards
            animateVisibleCards();
        }, 300);
    }
    
    // Update results display
    function updateResults(count, searchTerm) {
        // Update count badge
        labCount.innerHTML = `<i class="bi bi-building me-2"></i>${count} ${count === 1 ? 'Laboratory' : 'Laboratories'} Available`;
        
        // Update search indicator
        if (searchTerm.trim()) {
            searchIndicator.innerHTML = `<span>Showing results for: <strong>${searchTerm}</strong></span>`;
            searchIndicator.style.display = 'block';
        } else {
            searchIndicator.innerHTML = '';
            searchIndicator.style.display = 'none';
        }
        
        // Show/hide no results message
        if (count === 0 && searchTerm.trim()) {
            noResultsText.textContent = `No laboratories found for "${searchTerm}". Try different keywords.`;
            noResults.style.display = 'block';
            clearFilterBtn.style.display = 'inline-flex';
        } else if (count === 0) {
            noResultsText.textContent = 'No laboratories available.';
            noResults.style.display = 'block';
            clearFilterBtn.style.display = 'none';
        } else {
            noResults.style.display = 'none';
            clearFilterBtn.style.display = searchTerm.trim() ? 'inline-flex' : 'none';
        }
    }
    
    // Animate visible cards
    function animateVisibleCards() {
        const visibleCards = document.querySelectorAll('.lab-item:not(.lab-hidden)');
        visibleCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 50);
        });
    }
    
    // Initial animation
    animateVisibleCards();
    
    // Search input event listener with debouncing
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.trim();
        
        // Clear previous timeout
        clearTimeout(filterTimeout);
        
        // Show loading spinner for searches longer than 1 character
        if (searchTerm.length > 1 && !isFiltering) {
            loadingSpinner.style.display = 'block';
        }
        
        // Set timeout for debouncing (300ms delay)
        filterTimeout = setTimeout(() => {
            filterLabs(searchTerm);
        }, 300);
    });
    
    // Clear filter button
    clearFilterBtn.addEventListener('click', function() {
        searchInput.value = '';
        filterLabs('');
        searchInput.focus();
    });
    
    // Form submission handling
    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const searchTerm = searchInput.value.trim();
        
        if (searchTerm) {
            // If there's a search term, filter immediately
            filterLabs(searchTerm);
            
            // Smooth scroll to results
            setTimeout(() => {
                window.scrollTo({
                    top: document.querySelector('.container.pb-5').offsetTop - 100,
                    behavior: 'smooth'
                });
            }, 100);
        }
    });
    
    // Add keyboard shortcuts
    searchInput.addEventListener('keydown', function(e) {
        // Clear search with Escape key
        if (e.key === 'Escape') {
            this.value = '';
            filterLabs('');
        }
        
        // Focus on first result with Enter (when results are filtered)
        if (e.key === 'Enter' && this.value.trim()) {
            const firstVisibleLab = document.querySelector('.lab-item:not(.lab-hidden)');
            if (firstVisibleLab) {
                e.preventDefault();
                const viewBtn = firstVisibleLab.querySelector('.view-btn');
                if (viewBtn) {
                    // Add visual feedback
                    firstVisibleLab.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        firstVisibleLab.style.transform = '';
                        window.location.href = viewBtn.href;
                    }, 150);
                }
            }
        }
    });
    
    // Add search input focus effect
    searchInput.addEventListener('focus', function() {
        this.parentElement.parentElement.style.transform = 'translateY(-4px)';
        this.parentElement.parentElement.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.3)';
    });
    
    searchInput.addEventListener('blur', function() {
        this.parentElement.parentElement.style.transform = 'translateY(-2px)';
        this.parentElement.parentElement.style.boxShadow = '0 15px 40px rgba(0, 0, 0, 0.25)';
    });
    
    // Add click effect to lab cards
    document.querySelectorAll('.lab-item').forEach(card => {
        card.addEventListener('click', function(e) {
            // Don't trigger if clicking the view button
            if (e.target.closest('.view-btn')) {
                return;
            }
            
            // Optional: Add visual feedback
            this.style.transform = 'translateY(-12px) scale(1.02)';
            setTimeout(() => {
                this.style.transform = 'translateY(-10px)';
            }, 150);
            
            // Navigate to lab detail page
            const link = this.querySelector('.view-btn');
            if (link) {
                setTimeout(() => {
                    window.location.href = link.href;
                }, 300);
            }
        });
    });
    
    // Initialize with any existing search term
    const initialSearch = searchInput.value.trim();
    if (initialSearch) {
        filterLabs(initialSearch);
    }
});
</script>

<?= $this->endSection() ?>