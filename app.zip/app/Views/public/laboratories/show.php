<?= $this->extend('layouts/main_user') ?>
<?= $this->section('content') ?>

<style>
/* ============================================================
   LABORATORY DETAIL PAGE - COHESIVE DESIGN
   ============================================================ */
.lab-detail-page {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    min-height: 100vh;
    padding: 100px 0 60px;
}

/* Breadcrumb */
.lab-breadcrumb {
    margin-bottom: 30px;
}

.back-link {
    color: #3b82f6;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border-radius: 8px;
    background: white;
    box-shadow: 0 4px 15px rgba(30, 64, 175, 0.05);
}

.back-link:hover {
    color: #1e40af;
    background: #eff6ff;
    transform: translateX(-5px);
}

/* Lab Header Card */
.lab-header-card {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

.lab-header-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.lab-header-content {
    display: flex;
    gap: 30px;
    align-items: center;
}

.lab-header-info {
    flex: 1;
}

.lab-title {
    font-size: 2.5rem;
    font-weight: 900;
    color: #1e40af;
    margin-bottom: 15px;
    line-height: 1.2;
}

.lab-room {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: #64748b;
    font-size: 1.1rem;
    margin-bottom: 20px;
    padding: 6px 15px;
    background: #eff6ff;
    border-radius: 50px;
}

.lab-room i {
    color: #3b82f6;
}

.lab-description {
    color: #475569;
    line-height: 1.6;
    font-size: 1.05rem;
    max-width: 800px;
}

.lab-header-image {
    flex-shrink: 0;
    width: 280px;
    height: 180px;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(30, 64, 175, 0.1);
    border: 1px solid #e2e8f0;
}

.lab-header-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* PIC Card */
.pic-card {
    background: white;
    border-radius: 24px;
    padding: 30px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    position: relative;
    overflow: hidden;
}

.pic-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.pic-content {
    display: flex;
    gap: 20px;
    align-items: center;
}

.pic-avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    overflow: hidden;
    border: 3px solid #3b82f6;
    background: linear-gradient(135deg, #e0f2fe, #eff6ff);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.pic-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.pic-avatar i {
    font-size: 2.5rem;
    color: #3b82f6;
}

.pic-info {
    flex: 1;
}

.pic-label {
    color: #3b82f6;
    font-size: 0.9rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
}

.pic-name {
    color: #1e293b;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 15px;
}

.pic-contact {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.contact-item {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #475569;
    font-size: 0.95rem;
}

.contact-item i {
    color: #3b82f6;
    width: 20px;
}

.pic-note {
    margin-top: 20px;
    padding: 15px;
    background: #eff6ff;
    border-radius: 12px;
    border-left: 4px solid #3b82f6;
    font-size: 0.9rem;
    color: #1e40af;
}

.pic-note i {
    color: #1e40af;
    margin-right: 8px;
}

/* Equipment Section */
.equipment-card {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

.equipment-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.equipment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.equipment-title {
    font-size: 1.8rem;
    font-weight: 700;
    color: #1e40af;
    display: flex;
    align-items: center;
    gap: 12px;
}

.equipment-title i {
    color: #3b82f6;
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.equipment-badge {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    padding: 8px 20px;
    border-radius: 50px;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
}

/* Equipment Table */
.equipment-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
}

.equipment-table thead {
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
}

.equipment-table th {
    padding: 16px 20px;
    text-align: left;
    color: #1e40af;
    font-weight: 600;
    border-bottom: 2px solid #dbeafe;
}

.equipment-table tbody tr {
    transition: all 0.3s ease;
    border-bottom: 1px solid #f1f5f9;
}

.equipment-table tbody tr:hover {
    background: #f8fafc;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(30, 64, 175, 0.05);
}

.equipment-table td {
    padding: 20px;
    vertical-align: middle;
}

.equipment-checkbox {
    width: 50px;
    text-align: center;
}

.equipment-checkbox .form-check-input {
    width: 22px;
    height: 22px;
    border-radius: 6px;
    border: 2px solid #cbd5e1;
    cursor: pointer;
    transition: all 0.3s ease;
}

.equipment-checkbox .form-check-input:checked {
    background-color: #3b82f6;
    border-color: #3b82f6;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
}

.equipment-name {
    color: #1e293b;
    font-weight: 600;
    font-size: 1.05rem;
}

.equipment-desc {
    color: #64748b;
    font-size: 0.9rem;
    margin-top: 5px;
    line-height: 1.4;
}

.quantity-badge {
    background: #eff6ff;
    color: #1e40af;
    padding: 6px 16px;
    border-radius: 50px;
    font-weight: 600;
    font-size: 0.9rem;
    border: 1px solid #dbeafe;
}

.quantity-input {
    width: 100px;
    border-radius: 8px;
    border: 2px solid #e2e8f0;
    padding: 8px 12px;
    text-align: center;
    font-weight: 600;
    color: #1e293b;
    transition: all 0.3s ease;
}

.quantity-input:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    outline: none;
}

.quantity-input:disabled {
    background: #f8fafc;
    color: #cbd5e1;
    cursor: not-allowed;
}

/* Calendar Section */
.calendar-card {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

.calendar-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.calendar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.calendar-title {
    font-size: 1.8rem;
    font-weight: 700;
    color: #1e40af;
    display: flex;
    align-items: center;
    gap: 12px;
}

.calendar-title i {
    color: #3b82f6;
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.calendar-note {
    color: #64748b;
    font-size: 0.95rem;
    max-width: 600px;
}

/* Booking CTA Card */
.booking-card {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    position: relative;
    overflow: hidden;
}

.booking-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.booking-title {
    font-size: 1.8rem;
    font-weight: 700;
    color: #1e40af;
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 20px;
}

.booking-title i {
    color: #3b82f6;
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.booking-description {
    color: #475569;
    line-height: 1.6;
    margin-bottom: 25px;
    font-size: 1.05rem;
}

.booking-alert {
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
    border: none;
    border-radius: 16px;
    border-left: 4px solid #3b82f6;
    padding: 20px;
    margin-bottom: 25px;
}

.booking-alert i {
    color: #1e40af;
    margin-right: 10px;
}

.booking-alert p {
    color: #1e40af;
    margin: 0;
    font-size: 0.95rem;
}

.booking-btn {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    border: none;
    border-radius: 12px;
    padding: 16px 32px;
    font-weight: 600;
    font-size: 1.1rem;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    justify-content: center;
    box-shadow: 0 4px 20px rgba(59, 130, 246, 0.4);
}

.booking-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 30px rgba(59, 130, 246, 0.6);
    color: white;
}

.booking-btn-outline {
    background: transparent;
    color: #3b82f6;
    border: 2px solid #3b82f6;
}

.booking-btn-outline:hover {
    background: #3b82f6;
    color: white;
}

/* FullCalendar Custom Styling */
#labCalendar {
    border-radius: 16px;
    overflow: hidden;
    border: 1px solid #e2e8f0;
}

.fc .fc-toolbar {
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
    padding: 20px;
    border-radius: 16px 16px 0 0;
    margin: 0;
}

.fc .fc-toolbar-title {
    color: #1e40af;
    font-weight: 700;
    font-size: 1.3rem;
}

.fc .fc-button {
    background: white;
    border: 2px solid #dbeafe;
    color: #1e40af;
    font-weight: 600;
    border-radius: 8px;
    padding: 8px 16px;
    transition: all 0.3s ease;
}

.fc .fc-button:hover {
    background: #3b82f6;
    border-color: #3b82f6;
    color: white;
    transform: translateY(-2px);
}

.fc .fc-button-primary:not(:disabled).fc-button-active {
    background: #3b82f6;
    border-color: #3b82f6;
}

.fc .fc-daygrid-day {
    transition: all 0.3s ease;
}

.fc .fc-daygrid-day:hover {
    background: #f8fafc;
    transform: scale(1.02);
}

.fc .fc-daygrid-day.fc-day-today {
    background: #eff6ff;
}

.fc-event {
    border-radius: 8px;
    border: none;
    padding: 8px 12px;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* Responsive Design */
@media (max-width: 992px) {
    .lab-detail-page {
        padding: 80px 0 40px;
    }
    
    .lab-header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .lab-header-image {
        width: 100%;
        max-width: 400px;
    }
    
    .pic-content {
        flex-direction: column;
        text-align: center;
    }
    
    .equipment-header,
    .calendar-header {
        flex-direction: column;
        gap: 20px;
        text-align: center;
    }
    
    .equipment-table {
        display: block;
        overflow-x: auto;
    }
}

@media (max-width: 768px) {
    .lab-title {
        font-size: 2rem;
    }
    
    .lab-header-card,
    .pic-card,
    .equipment-card,
    .calendar-card,
    .booking-card {
        padding: 25px;
    }
    
    .equipment-title,
    .calendar-title,
    .booking-title {
        font-size: 1.5rem;
    }
}
</style>

<!-- ============================================================
     LABORATORY DETAIL PAGE CONTENT
     ============================================================ -->
<div class="lab-detail-page">
    <div class="container">
        
        <!-- Breadcrumb -->
        <div class="lab-breadcrumb">
            <a href="<?= site_url('/laboratories') ?>" class="back-link">
                <i class="bi bi-arrow-left"></i>
                Back to Laboratory Directory
            </a>
        </div>

        <!-- Lab Header -->
        <div class="lab-header-card">
            <div class="lab-header-content">
                <div class="lab-header-info">
                    <h1 class="lab-title"><?= esc($lab['name']) ?></h1>
                    
                    <?php if (!empty($lab['room'])): ?>
                        <div class="lab-room">
                            <i class="bi bi-door-open"></i>
                            Room <?= esc($lab['room']) ?>
                        </div>
                    <?php endif; ?>
                    
                    <p class="lab-description">
                        Select equipment, check real-time availability, and submit your booking request 
                        for this state-of-the-art laboratory facility.
                    </p>
                </div>
                
                <?php if (!empty($lab['image'])): ?>
                    <div class="lab-header-image">
                        <img src="<?= esc($lab['image']) ?>" 
                             alt="<?= esc($lab['name']) ?>">
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row g-4">
            <!-- Person in Charge Card -->
            <div class="col-lg-4">
                <div class="pic-card">
                    <div class="pic-content">
                        <div class="pic-avatar">
                            <?php if (!empty($lab['pic_image'])): ?>
                                <img src="<?= esc($lab['pic_image']) ?>" 
                                     alt="<?= esc($lab['pic_name']) ?>">
                            <?php else: ?>
                                <i class="bi bi-person-gear"></i>
                            <?php endif; ?>
                        </div>
                        
                        <div class="pic-info">
                            <div class="pic-label">Person in Charge</div>
                            <div class="pic-name"><?= esc($lab['pic_name']) ?></div>
                            
                            <div class="pic-contact">
                                <?php if (!empty($lab['pic_email'])): ?>
                                    <div class="contact-item">
                                        <i class="bi bi-envelope"></i>
                                        <?= esc($lab['pic_email']) ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($lab['pic_phone'])): ?>
                                    <div class="contact-item">
                                        <i class="bi bi-telephone"></i>
                                        <?= esc($lab['pic_phone']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="pic-note">
                        <i class="bi bi-info-circle"></i>
                        External users and guests must contact the PIC to arrange bookings.
                    </div>
                </div>
            </div>

            <!-- Equipment Section -->
            <div class="col-lg-8">
                <div class="equipment-card">
                    <div class="equipment-header">
                        <h2 class="equipment-title">
                            <i class="bi bi-tools"></i>
                            Available Equipment
                        </h2>
                        <span class="equipment-badge">
                            <?= count($assets) ?> Equipment Available
                        </span>
                    </div>
                    
                    <?php if (empty($assets)): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-tools text-primary fs-1 mb-3"></i>
                            <h4 class="fw-semibold text-primary mb-2">No Equipment Configured</h4>
                            <p class="text-muted">This laboratory does not have any equipment listed yet.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="equipment-table">
                                <thead>
                                    <tr>
                                        <th class="equipment-checkbox"></th>
                                        <th>Equipment Details</th>
                                        <th class="text-center">Available</th>
                                        <th class="text-center">Request Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($assets as $a): ?>
                                        <tr>
                                            <td class="equipment-checkbox">
                                                <input type="checkbox"
                                                       class="form-check-input asset-checkbox"
                                                       data-asset-id="<?= esc($a['id']) ?>">
                                            </td>
                                            <td>
                                                <div class="equipment-name"><?= esc($a['name']) ?></div>
                                                <?php if (!empty($a['description'])): ?>
                                                    <div class="equipment-desc"><?= esc($a['description']) ?></div>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <span class="quantity-badge">
                                                    <?= esc($a['quantity']) ?> Units
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <input type="number"
                                                       class="form-control quantity-input asset-qty"
                                                       data-asset-id="<?= esc($a['id']) ?>"
                                                       value="1" min="1"
                                                       max="<?= esc($a['quantity']) ?>"
                                                       disabled>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Booking CTA Card -->
        <div class="booking-card">
            <h2 class="booking-title">
                <i class="bi bi-calendar-check"></i>
                <?php if ($bookingMode === 'uthm'): ?>
                    Ready to Book?
                <?php else: ?>
                    How to Book This Laboratory
                <?php endif; ?>
            </h2>
            
            <p class="booking-description">
                <?php if ($bookingMode === 'uthm'): ?>
                    Select your required equipment above, check the calendar availability below, 
                    then launch the booking wizard to complete your reservation request.
                <?php else: ?>
                    You can browse equipment and view availability, but online booking is exclusively 
                    available for UTHM users. External users should contact the Person in Charge.
                <?php endif; ?>
            </p>
            
            <div class="booking-alert">
                <i class="bi bi-info-circle"></i>
                <p>Availability is calculated based on your selected equipment and may vary between timeslots.</p>
            </div>
            
            <?php if ($bookingMode === 'uthm'): ?>
                <button id="openBookingWizardBtn"
                        class="btn booking-btn"
                        data-lab-id="<?= esc($lab['id']) ?>">
                    <i class="bi bi-magic me-1"></i>
                    Launch Booking Wizard
                </button>
            <?php else: ?>
                <button id="openBookingWizardBtn"
                        class="btn booking-btn booking-btn-outline"
                        type="button">
                    <i class="bi bi-person-gear me-1"></i>
                    Contact PIC for Booking
                </button>
            <?php endif; ?>
        </div>

        <!-- Calendar Section -->
        <div class="calendar-card">
            <div class="calendar-header">
                <h2 class="calendar-title">
                    <i class="bi bi-calendar3"></i>
                    Laboratory Availability
                </h2>
                <div class="calendar-note">
                    Select equipment above to view real-time availability. Click on any date to see available timeslots.
                </div>
            </div>
            <div id="labCalendar"></div>
        </div>

    </div>
</div>

<!-- Include booking modal (adapts to bookingMode inside) -->
<?= $this->include('public/booking/booking_modal', [
    'lab'          => $lab,
    'faculties'    => $faculties,
    'bookingMode'  => $bookingMode
]) ?>

<!-- FULLCALENDAR -->
<link rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const LAB_ID      = <?= (int) $lab['id'] ?>;
    const BOOKING_MODE = "<?= esc($bookingMode) ?>";

    const calendarEl       = document.getElementById("labCalendar");
    const assetCheckboxes  = document.querySelectorAll(".asset-checkbox");
    const openWizardBtn    = document.getElementById("openBookingWizardBtn");
    const hiddenAssetField = document.getElementById("asset_selection_modal");
    const hiddenLabIdInput = document.getElementById("labIdInput");

    // -------------------------------
    // Build "1:2,5:1" asset string
    // -------------------------------
    function buildAssetSelectionString() {
        const parts = [];
        document.querySelectorAll(".asset-checkbox").forEach(cb => {
            const id = cb.dataset.assetId;
            const qtyInput = document.querySelector(`.asset-qty[data-asset-id="${id}"]`);
            if (cb.checked && qtyInput && qtyInput.value) {
                const qty = parseInt(qtyInput.value, 10);
                if (!isNaN(qty) && qty > 0) {
                    parts.push(`${id}:${qty}`);
                }
            }
        });
        return parts.join(",");
    }

    // Enable/disable quantity inputs with animations
    assetCheckboxes.forEach(cb => {
        cb.addEventListener("change", () => {
            const id = cb.dataset.assetId;
            const qtyInput = document.querySelector(`.asset-qty[data-asset-id="${id}"]`);
            const row = cb.closest('tr');
            
            if (!qtyInput) return;

            // Add visual feedback
            if (cb.checked) {
                row.style.transform = 'translateY(-2px)';
                row.style.boxShadow = '0 4px 15px rgba(59, 130, 246, 0.1)';
                qtyInput.disabled = false;
                qtyInput.style.borderColor = '#3b82f6';
                if (!qtyInput.value || parseInt(qtyInput.value, 10) < 1) {
                    qtyInput.value = 1;
                }
            } else {
                row.style.transform = '';
                row.style.boxShadow = '';
                qtyInput.disabled = true;
                qtyInput.style.borderColor = '#e2e8f0';
            }

            setTimeout(() => {
                row.style.transition = 'all 0.3s ease';
            }, 10);

            refreshCalendar();
        });
    });

    document.querySelectorAll(".asset-qty").forEach(input => {
        input.addEventListener("change", () => {
            if (parseInt(input.value, 10) < 1) input.value = 1;
            const max = parseInt(input.max, 10);
            if (parseInt(input.value, 10) > max) input.value = max;
            
            // Visual feedback
            input.style.transform = 'scale(1.05)';
            setTimeout(() => {
                input.style.transform = '';
                input.style.transition = 'transform 0.2s ease';
            }, 200);
            
            refreshCalendar();
        });
    });


    // -------------------------------
    // FullCalendar setup with custom styling
    // -------------------------------
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        height: "auto",
        eventDisplay: "block",
        headerToolbar: {
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,timeGridDay"
        },
        buttonText: {
            today: "Today",
            month: "Month",
            week: "Week",
            day: "Day"
        },
        dateClick: (info) => {
            loadDaySlots(info.dateStr);
        },
        eventDidMount: (info) => {
            // Add tooltip for events
            info.el.title = info.event.title;
        },
        datesSet: () => {
            // Refresh calendar when view changes
            refreshCalendar();
        }
    });

    calendar.render();


    // -------------------------------
    // Refresh availability on calendar
    // -------------------------------
    function refreshCalendar() {
        const assets = buildAssetSelectionString();
        if (!assets) {
            calendar.removeAllEvents();
            calendar.addEvent({
                title: "Select equipment to view availability",
                start: new Date(),
                allDay: true,
                color: "#94a3b8",
                display: "background"
            });
            return;
        }

        // Show loading state
        calendar.updateSize();
        
        fetch(`/api/calendar-with-assets/${LAB_ID}?assets=${encodeURIComponent(assets)}`)
            .then(r => r.json())
            .then(data => {
                calendar.removeAllEvents();

                (data.unavailableDates || []).forEach(date => {
                    calendar.addEvent({
                        start: date,
                        allDay: true,
                        title: "Fully Unavailable",
                        color: "#ef4444",
                        classNames: ["fc-event-unavailable"]
                    });
                });

                // Add available dates if needed
                if (data.availableDates && data.availableDates.length > 0) {
                    data.availableDates.forEach(date => {
                        calendar.addEvent({
                            start: date,
                            allDay: true,
                            title: "Available",
                            color: "#10b981",
                            classNames: ["fc-event-available"]
                        });
                    });
                }
            })
            .catch(() => {
                // Show error state
                calendar.addEvent({
                    title: "Error loading availability",
                    start: new Date(),
                    allDay: true,
                    color: "#f97316"
                });
            });
    }


    // -------------------------------
    // Load day slots for clicked date
    // -------------------------------
    function loadDaySlots(dateStr) {
        const assets = buildAssetSelectionString();
        if (!assets) {
            showAlert("Please select at least one equipment item first.", "warning");
            return;
        }

        // Show loading
        showLoadingPopup();

        fetch(`/api/bookings/day-with-assets/${LAB_ID}/${dateStr}?assets=${encodeURIComponent(assets)}`)
            .then(r => r.json())
            .then(data => {
                showSlotPopup(dateStr, data.slots || []);
            })
            .catch(() => {
                showAlert("Unable to load timeslots for this date.", "error");
            });
    }


    // -------------------------------
    // Timeslot popup - Enhanced Design
    // -------------------------------
    function showSlotPopup(dateStr, slots) {
        const formattedDate = new Date(dateStr).toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        let html = `
            <div class="slot-popup">
                <div class="slot-header mb-4">
                    <h4 class="fw-bold text-primary mb-1">${formattedDate}</h4>
                    <p class="text-muted mb-0">Available timeslots for selected equipment</p>
                </div>
        `;

        if (!slots.length) {
            html += `
                <div class="no-slots text-center py-4">
                    <i class="bi bi-calendar-x text-primary fs-1 mb-3"></i>
                    <p class="text-muted">No timeslots available for this date.</p>
                </div>
            `;
        }

        slots.forEach((slot, index) => {
            const colorClass = slot.can_book ? "slot-available" : "slot-unavailable";
            const statusText = slot.can_book ? "Available" : "Unavailable";
            const statusIcon = slot.can_book ? "bi-check-circle" : "bi-x-circle";

            html += `
                <div class="slot-item ${colorClass} mb-3">
                    <div class="slot-info">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <h6 class="fw-semibold mb-0">${slot.label}</h6>
                                <small class="text-muted">${slot.start} - ${slot.end}</small>
                            </div>
                            <span class="slot-status badge ${slot.can_book ? 'bg-success' : 'bg-secondary'}">
                                <i class="bi ${statusIcon} me-1"></i>${statusText}
                            </span>
                        </div>

                        <div class="slot-assets">
                            <small class="d-block mb-1"><strong>Equipment Status:</strong></small>
                            <ul class="mb-0 ps-3">
            `;

            (slot.assets || []).forEach(a => {
                const icon = a.remaining >= a.requested ? "bi-check-circle text-success" : "bi-x-circle text-danger";
                html += `
                    <li class="small">
                        <i class="bi ${icon} me-1"></i>
                        ${a.name}: Requested ${a.requested}, Available ${a.remaining}
                    </li>
                `;
            });

            html += `</ul>`;

            if (slot.can_book && BOOKING_MODE === "uthm") {
                html += `
                    <button class="btn btn-primary btn-sm w-100 mt-3"
                            type="button"
                            onclick="selectSlot('${dateStr}', '${slot.start}', '${slot.end}')">
                        <i class="bi bi-calendar-plus me-1"></i>Book This Slot
                    </button>
                `;
            } else if (slot.can_book && BOOKING_MODE !== "uthm") {
                html += `
                    <div class="alert alert-warning small mt-3 mb-0">
                        <i class="bi bi-person-gear me-1"></i>
                        Online booking is only available for UTHM users. Please contact the PIC.
                    </div>
                `;
            }

            html += `</div></div></div>`;
        });

        html += `</div>`;

        const modal = document.createElement("div");
        modal.className = "modal fade";
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content shadow-lg" style="border-radius: 20px; border: none;">
                    <div class="modal-header border-0 pb-0">
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body pt-0">${html}</div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();

        modal.addEventListener("hidden.bs.modal", () => modal.remove());
    }

    function showLoadingPopup() {
        const modal = document.createElement("div");
        modal.className = "modal fade";
        modal.innerHTML = `
            <div class="modal-dialog modal-sm">
                <div class="modal-content border-0 shadow-lg">
                    <div class="modal-body text-center py-4">
                        <div class="spinner-border text-primary mb-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mb-0">Loading timeslots...</p>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
        // Auto remove after 3 seconds if still showing
        setTimeout(() => {
            if (document.body.contains(modal)) {
                bsModal.hide();
                modal.remove();
            }
        }, 3000);
    }

    function showAlert(message, type = "info") {
        const alertClass = {
            info: "alert-info",
            warning: "alert-warning",
            error: "alert-danger",
            success: "alert-success"
        }[type];

        const alert = document.createElement("div");
        alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
        alert.style.cssText = `
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            border-radius: 12px;
            border: none;
        `;
        alert.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="bi ${type === 'warning' ? 'bi-exclamation-triangle' : type === 'error' ? 'bi-x-circle' : 'bi-info-circle'} me-2"></i>
                <div class="flex-grow-1">${message}</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;

        document.body.appendChild(alert);
        
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 5000);
    }


    // -------------------------------------------------
    // Global function used by popup "Book This Slot"
    // -------------------------------------------------
    window.selectSlot = function(dateStr, start, end) {
        if (BOOKING_MODE !== "uthm") {
            showAlert("Online booking is only available for UTHM users.", "warning");
            return;
        }

        const bookingModalEl = document.getElementById("bookingModal");
        const dateField      = document.getElementById("selectedDate");
        const startField     = document.getElementById("startTime");
        const endField       = document.getElementById("endTime");

        const assetsString = buildAssetSelectionString();
        if (!assetsString) {
            showAlert("Please select at least one equipment item before booking.", "warning");
            return;
        }

        if (hiddenAssetField) hiddenAssetField.value = assetsString;
        if (hiddenLabIdInput) hiddenLabIdInput.value = LAB_ID;

        if (dateField)  dateField.value  = dateStr;
        if (startField) startField.value = start;
        if (endField)   endField.value   = end;

        if (window.resetBookingWizard) {
            window.resetBookingWizard();
        }

        const modal = new bootstrap.Modal(bookingModalEl);
        modal.show();
    };


    // -------------------------------------------------
    // "Launch Booking Wizard" button behaviour
    // -------------------------------------------------
    if (openWizardBtn) {
        openWizardBtn.addEventListener("click", () => {
            // Non-UTHM: show simple PIC info modal
            if (BOOKING_MODE !== "uthm") {
                const modalEl = document.getElementById("bookingModal");
                if (modalEl) {
                    const modal = new bootstrap.Modal(modalEl);
                    modal.show();
                } else {
                    showAlert("For external bookings, please contact the Person in Charge shown above.", "info");
                }
                return;
            }

            // UTHM: normal booking wizard flow
            const assetsString = buildAssetSelectionString();
            if (!assetsString) {
                showAlert("Please select at least one equipment item before proceeding.", "warning");
                return;
            }

            if (hiddenAssetField) hiddenAssetField.value = assetsString;
            if (hiddenLabIdInput) hiddenLabIdInput.value = LAB_ID;

            if (window.resetBookingWizard) {
                window.resetBookingWizard();
            }

            const bookingModalEl = document.getElementById("bookingModal");
            const modal = new bootstrap.Modal(bookingModalEl);
            modal.show();
        });
    }

    // Add styles for slot popup
    const style = document.createElement('style');
    style.textContent = `
        .slot-popup { padding: 10px; }
        .slot-item { 
            border-radius: 12px; 
            padding: 20px; 
            border: 2px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        .slot-item:hover { 
            transform: translateY(-2px); 
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        .slot-available { border-color: #dbeafe; background: #f8fafc; }
        .slot-unavailable { border-color: #fecaca; background: #fef2f2; }
        .slot-assets ul { list-style: none; }
        .slot-assets li { margin-bottom: 4px; }
        .fc-event-unavailable { background: #ef4444; border: none; }
        .fc-event-available { background: #10b981; border: none; }
    `;
    document.head.appendChild(style);

    // Initial calendar load
    refreshCalendar();
});
</script>

<?= $this->endSection() ?>