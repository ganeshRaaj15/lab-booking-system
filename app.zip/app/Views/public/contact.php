<?= $this->extend('layouts/main_user') ?>
<?= $this->section('content') ?>

<style>
/* ============================================================
   CONTACT PAGE - COHESIVE WITH HOMEPAGE COLOR SCHEME
   ============================================================ */
.contact-page {
    padding: 100px 0 60px;
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    min-height: 100vh;
}

.contact-header {
    text-align: center;
    margin-bottom: 60px;
}

.contact-title {
    font-size: 3rem;
    font-weight: 900;
    color: #1e40af;
    margin-bottom: 20px;
    position: relative;
    display: inline-block;
}

.contact-title::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 2px;
}

.contact-subtitle {
    color: #64748b;
    font-size: 1.2rem;
    max-width: 600px;
    margin: 30px auto 0;
    line-height: 1.6;
}

/* Card Design */
.contact-card {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    transition: all 0.4s ease;
    height: 100%;
    position: relative;
    overflow: hidden;
}

.contact-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.contact-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 60px rgba(30, 64, 175, 0.12);
    border-color: #3b82f6;
}

/* Faculty Building Image */
.contact-img {
    width: 100%;
    border-radius: 16px;
    object-fit: cover;
    height: 220px;
    box-shadow: 0 10px 30px rgba(30, 64, 175, 0.1);
    margin-bottom: 25px;
    transition: transform 0.3s ease;
    border: 1px solid #e2e8f0;
}

.contact-img:hover {
    transform: scale(1.02);
}

/* Faculty Info */
.faculty-title {
    color: #1e293b;
    font-weight: 700;
    font-size: 1.5rem;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.faculty-title i {
    color: #3b82f6;
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.faculty-info {
    color: #475569;
    margin-bottom: 20px;
    line-height: 1.8;
    font-size: 1rem;
}

.contact-detail {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #475569;
    margin-bottom: 15px;
    transition: all 0.3s ease;
    padding: 12px 16px;
    border-radius: 12px;
    background: #f8fafc;
    border: 1px solid #f1f5f9;
}

.contact-detail:hover {
    background: #eff6ff;
    border-color: #dbeafe;
    transform: translateX(5px);
}

.contact-detail i {
    color: #3b82f6;
    font-size: 1.2rem;
    width: 24px;
    text-align: center;
}

.contact-detail strong {
    color: #1e40af;
    margin-right: 5px;
}

/* Staff Cards */
.staff-section-title {
    color: #1e293b;
    font-weight: 700;
    font-size: 1.5rem;
    margin-bottom: 30px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.staff-section-title i {
    color: #3b82f6;
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.staff-card {
    background: white;
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 20px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 8px 25px rgba(30, 64, 175, 0.05);
    transition: all 0.4s ease;
    display: flex;
    gap: 20px;
    align-items: flex-start;
}

.staff-card:hover {
    transform: translateY(-5px);
    border-color: #3b82f6;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.1);
    background: #f8fafc;
}

.staff-photo {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #3b82f6;
    background: white;
    padding: 3px;
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.15);
    transition: all 0.3s ease;
}

.staff-card:hover .staff-photo {
    transform: scale(1.05);
    border-color: #1e40af;
    box-shadow: 0 8px 25px rgba(30, 64, 175, 0.2);
}

.staff-info {
    flex: 1;
}

.staff-name {
    color: #1e293b;
    font-weight: 700;
    font-size: 1.2rem;
    margin-bottom: 6px;
}

.staff-role {
    color: #3b82f6;
    font-size: 0.9rem;
    margin-bottom: 15px;
    font-weight: 500;
    background: #eff6ff;
    padding: 4px 12px;
    border-radius: 20px;
    display: inline-block;
}

.staff-contact {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.contact-link {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #475569;
    text-decoration: none;
    transition: all 0.3s ease;
    padding: 8px 12px;
    border-radius: 8px;
    background: #f8fafc;
    border: 1px solid #f1f5f9;
}

.contact-link:hover {
    color: #1e40af;
    background: #eff6ff;
    border-color: #dbeafe;
    transform: translateX(5px);
    text-decoration: none;
}

.contact-link i {
    color: #3b82f6;
    font-size: 1.1rem;
    width: 20px;
}

/* Info Notes */
.contact-note {
    margin-top: 30px;
    padding: 20px;
    background: linear-gradient(135deg, #eff6ff, #dbeafe);
    border-radius: 16px;
    border-left: 4px solid #3b82f6;
}

.contact-note p {
    color: #1e40af;
    margin: 0;
    font-size: 0.95rem;
    line-height: 1.6;
}

.contact-note i {
    color: #1e40af;
    margin-right: 8px;
}

/* Map Section */
.map-section {
    margin-top: 60px;
    padding: 40px;
    background: white;
    border-radius: 24px;
    box-shadow: 0 15px 40px rgba(30, 64, 175, 0.08);
    border: 1px solid #e2e8f0;
    position: relative;
    overflow: hidden;
}

.map-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 24px 24px 0 0;
}

.map-title {
    color: #1e40af;
    font-weight: 700;
    font-size: 1.5rem;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.map-title i {
    color: #3b82f6;
    background: linear-gradient(135deg, #dbeafe, #eff6ff);
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.map-container {
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(30, 64, 175, 0.1);
    border: 1px solid #e2e8f0;
    height: 400px;
    position: relative;
}

.map-container iframe {
    width: 100%;
    height: 100%;
    border: none;
}

.map-actions {
    display: flex;
    gap: 15px;
    margin-top: 20px;
    flex-wrap: wrap;
}

.map-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: #eff6ff;
    color: #1e40af;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    transition: all 0.3s ease;
    border: 1px solid #dbeafe;
}

.map-btn:hover {
    background: #3b82f6;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
    text-decoration: none;
    border-color: #3b82f6;
}

.map-btn i {
    font-size: 1.1rem;
}

.map-info {
    margin-top: 20px;
    padding: 15px 20px;
    background: #f8fafc;
    border-radius: 12px;
    border-left: 3px solid #3b82f6;
}

.map-info p {
    margin: 0;
    color: #475569;
    font-size: 0.95rem;
}

.map-info strong {
    color: #1e40af;
}

/* Responsive Design */
@media (max-width: 768px) {
    .contact-page {
        padding: 80px 0 40px;
    }
    
    .contact-title {
        font-size: 2.2rem;
    }
    
    .contact-subtitle {
        font-size: 1rem;
    }
    
    .contact-card {
        padding: 25px;
    }
    
    .staff-card {
        flex-direction: column;
        text-align: center;
        align-items: center;
    }
    
    .staff-contact {
        width: 100%;
    }
    
    .contact-link {
        justify-content: center;
    }
    
    .faculty-title,
    .staff-section-title,
    .map-title {
        flex-direction: column;
        text-align: center;
        gap: 15px;
    }
    
    .faculty-title i,
    .staff-section-title i,
    .map-title i {
        margin: 0 auto;
    }
    
    .map-container {
        height: 300px;
    }
    
    .map-actions {
        justify-content: center;
    }
    
    .map-section {
        padding: 25px;
    }
}
</style>

<!-- ============================================================
     CONTACT PAGE CONTENT
     ============================================================ -->
<div class="contact-page">
    <div class="container">
        
        <!-- Page Header -->
        <div class="contact-header">
            <h1 class="contact-title">Contact Us</h1>
            <p class="contact-subtitle">
                Get in touch with the Faculty of Mechanical & Manufacturing Engineering (FKMP) at UTHM.
                Our team is here to assist you with laboratory inquiries and booking support.
            </p>
        </div>

        <div class="row gy-4">
            
            <!-- =========================================== -->
            <!-- LEFT COLUMN: FKMP Information              -->
            <!-- =========================================== -->
            <div class="col-lg-6">
                <div class="contact-card">
                    <!-- Faculty Building Image -->
                    <img src="<?= base_url('images/fkmp/FKMP.jpeg') ?>"
                         alt="FKMP Building, UTHM"
                         class="contact-img"
                         onerror="this.src='https://images.unsplash.com/photo-1562774053-701939374585?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'">

                    <!-- Faculty Information -->
                    <h4 class="faculty-title">
                        <i class="bi bi-building"></i>
                        Faculty of Mechanical & Manufacturing Engineering
                    </h4>
                    
                    <p class="faculty-info">
                        <strong>Universiti Tun Hussein Onn Malaysia (UTHM)</strong><br>
                        86400, Parit Raja, Batu Pahat,<br>
                        Johor, Malaysia
                    </p>

                    <!-- Contact Details -->
                    <div class="contact-details">
                        <div class="contact-detail">
                            <i class="bi bi-telephone-fill"></i>
                            <div>
                                <strong>Phone:</strong> +607 4537703
                            </div>
                        </div>
                        
                        <div class="contact-detail">
                            <i class="bi bi-printer-fill"></i>
                            <div>
                                <strong>Fax:</strong> +607 4536080
                            </div>
                        </div>
                        
                        <div class="contact-detail">
                            <i class="bi bi-clock-fill"></i>
                            <div>
                                <strong>Operating Hours:</strong> 8:00 AM - 5:00 PM (Monday - Friday)
                            </div>
                        </div>
                        
                        <div class="contact-detail">
                            <i class="bi bi-geo-alt-fill"></i>
                            <div>
                                <strong>Location:</strong> Main Campus, Parit Raja
                            </div>
                        </div>
                    </div>

                    <!-- Additional Note -->
                    <div class="contact-note">
                        <p>
                            <i class="bi bi-info-circle-fill"></i>
                            For general inquiries about our facilities and academic programs, 
                            feel free to contact us during office hours.
                        </p>
                    </div>
                </div>
            </div>

            <!-- =========================================== -->
            <!-- RIGHT COLUMN: Staff Contacts                -->
            <!-- =========================================== -->
            <div class="col-lg-6">
                <div class="contact-card">
                    <h4 class="staff-section-title">
                        <i class="bi bi-people-fill"></i>
                        Key Personnel Contacts
                    </h4>

                    <!-- Office Secretary -->
                    <div class="staff-card">
                        <img src="<?= base_url('images/staff/haslina_placeholder.jpg') ?>"
                             class="staff-photo"
                             alt="Mrs. Haslina binti Abd. Rashid"
                             onerror="this.src='https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'">

                        <div class="staff-info">
                            <div class="staff-name">Mrs. Haslina binti Abd. Rashid</div>
                            <div class="staff-role">Office Secretary, Dean Office</div>
                            
                            <div class="staff-contact">
                                <a href="tel:+6074537703" class="contact-link">
                                    <i class="bi bi-telephone-fill"></i>
                                    <span>+607 4537703</span>
                                </a>
                                
                                <a href="mailto:haslinar@uthm.edu.my" class="contact-link">
                                    <i class="bi bi-envelope-fill"></i>
                                    <span>haslinar@uthm.edu.my</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Assistant Registrar -->
                    <div class="staff-card">
                        <img src="<?= base_url('images/staff/asyarofah_placeholder.jpg') ?>"
                             class="staff-photo"
                             alt="Mrs. Asyarofah bt. Othman"
                             onerror="this.src='https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'">

                        <div class="staff-info">
                            <div class="staff-name">Mrs. Asyarofah bt. Othman</div>
                            <div class="staff-role">Assistant Registrar, Academic Division</div>
                            
                            <div class="staff-contact">
                                <a href="tel:+6074537351" class="contact-link">
                                    <i class="bi bi-telephone-fill"></i>
                                    <span>+607 4537351</span>
                                </a>
                                
                                <a href="mailto:asyarofa@uthm.edu.my" class="contact-link">
                                    <i class="bi bi-envelope-fill"></i>
                                    <span>asyarofa@uthm.edu.my</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Web Administrator -->
                    <div class="staff-card">
                        <img src="<?= base_url('images/staff/azwan_placeholder.jpg') ?>"
                             class="staff-photo"
                             alt="Dr. Azwan Bin Sapit"
                             onerror="this.src='https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'">

                        <div class="staff-info">
                            <div class="staff-name">Dr. Azwan Bin Sapit</div>
                            <div class="staff-role">Web Administrator</div>
                            
                            <div class="staff-contact">
                                <a href="tel:+6074538470" class="contact-link">
                                    <i class="bi bi-telephone-fill"></i>
                                    <span>+607 4538470</span>
                                </a>
                                
                                <a href="mailto:azwans@uthm.edu.my" class="contact-link">
                                    <i class="bi bi-envelope-fill"></i>
                                    <span>azwans@uthm.edu.my</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Laboratory Support Note -->
                    <div class="contact-note">
                        <p>
                            <i class="bi bi-shield-check"></i>
                            For laboratory-related inquiries or booking assistance through SLAMS, 
                            please contact the relevant personnel listed above.
                        </p>
                    </div>
                </div>
            </div>

        </div>

        <!-- Map Section with Google Maps Embed -->
        <div class="map-section">
            <h4 class="map-title">
                <i class="bi bi-geo-alt-fill"></i>
                Campus Location
            </h4>
            
            <!-- Google Maps Embed -->
            <div class="map-container">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3982.919158657578!2d103.0859238!3d1.8564176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d05fa8c1d6b90f%3A0xfa4a13957533a50f!2sFaculty%20of%20Mechanical%20%26%20Manufacturing%20Engineering%2C%20Universiti%20Tun%20Hussein%20Onn%20Malaysia%20(UTHM)!5e0!3m2!1sen!2smy!4v1700000000000!5m2!1sen!2smy" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
            
            <!-- Map Action Buttons -->
            <div class="map-actions">
                <a href="https://www.google.com/maps/dir//Faculty+of+Mechanical+%26+Manufacturing+Engineering,+Universiti+Tun+Hussein+Onn+Malaysia+(UTHM),+86400+Parit+Raja,+Batu+Pahat,+Johor/@1.8564176,103.0859238,17z/data=!4m9!4m8!1m0!1m5!1m1!1s0x31d05fa8c1d6b90f:0xfa4a13957533a50f!2m2!1d103.0881125!2d1.8564176!3e0?entry=ttu" 
                   target="_blank" 
                   class="map-btn">
                    <i class="bi bi-signpost"></i>
                    Get Directions
                </a>
                
                <a href="https://www.google.com/maps/place/Faculty+of+Mechanical+%26+Manufacturing+Engineering,+Universiti+Tun+Hussein+Onn+Malaysia+(UTHM)/data=!4m7!3m6!1s0x31d05fa8c1d6b90f:0xfa4a13957533a50f!8m2!3d1.8564176!4d103.0881125!16s%2Fg%2F11hz_83sj7!19sChIJD7nWwahf0DERD6UzdZUTSvo?authuser=0&hl=en&rclk=1" 
                   target="_blank" 
                   class="map-btn">
                    <i class="bi bi-google"></i>
                    Open in Google Maps
                </a>
                
                <a href="https://waze.com/ul?ll=1.8564176,103.0881125&navigate=yes" 
                   target="_blank" 
                   class="map-btn">
                    <i class="bi bi-signpost-split"></i>
                    Open in Waze
                </a>
            </div>
            
            <!-- Map Information -->
            <div class="map-info">
                <p>
                    <strong>📍 Exact Coordinates:</strong> 1.8564176° N, 103.0881125° E<br>
                    <strong>🚗 Parking:</strong> Available at nearby faculty parking lots<br>
                    <strong>🚌 Public Transport:</strong> UTHM shuttle bus stops nearby
                </p>
            </div>
        </div>

    </div>
</div>

<script>
// Add interactive effects
document.addEventListener('DOMContentLoaded', function() {
    // Add hover effect to staff cards
    const staffCards = document.querySelectorAll('.staff-card');
    
    staffCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.cursor = 'pointer';
        });
        
        card.addEventListener('click', function(e) {
            // Don't trigger if clicking a link
            if (e.target.tagName === 'A' || e.target.closest('a')) {
                return;
            }
            
            // Optional: Add click effect
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
    
    // Add animation to contact details on page load
    const contactDetails = document.querySelectorAll('.contact-detail');
    contactDetails.forEach((detail, index) => {
        detail.style.opacity = '0';
        detail.style.transform = 'translateX(-20px)';
        
        setTimeout(() => {
            detail.style.transition = 'all 0.5s ease';
            detail.style.opacity = '1';
            detail.style.transform = 'translateX(0)';
        }, 300 + (index * 100));
    });
    
    // Add animation to staff cards on page load
    const staffCardsAnimate = document.querySelectorAll('.staff-card');
    staffCardsAnimate.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 500 + (index * 150));
    });
    
    // Add animation to map section
    const mapSection = document.querySelector('.map-section');
    if (mapSection) {
        mapSection.style.opacity = '0';
        mapSection.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            mapSection.style.transition = 'all 0.8s ease';
            mapSection.style.opacity = '1';
            mapSection.style.transform = 'translateY(0)';
        }, 800);
    }
    
    // Add hover effect to map buttons
    const mapButtons = document.querySelectorAll('.map-btn');
    mapButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            const icon = this.querySelector('i');
            if (icon) {
                icon.style.transform = 'scale(1.2)';
                icon.style.transition = 'transform 0.3s ease';
            }
        });
        
        button.addEventListener('mouseleave', function() {
            const icon = this.querySelector('i');
            if (icon) {
                icon.style.transform = 'scale(1)';
            }
        });
    });
});
</script>

<?= $this->endSection() ?>