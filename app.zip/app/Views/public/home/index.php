<?= $this->extend('layouts/main_user') ?>
<?= $this->section('content') ?>

<style>
/* ============================================================
   HERO SECTION WITH VIDEO BACKGROUND
   ============================================================ */
.hero-section {
    position: relative;
    height: 85vh;
    min-height: 600px;
    border-radius: 0 0 32px 32px;
    overflow: hidden;
    margin-bottom: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.video-background {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
}

.video-background video {
    width: 100%;
    height: 100%;
    object-fit: cover;
    filter: brightness(0.7) contrast(1.1);
}

/* Overlay for better text readability */
.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        to bottom,
        rgba(10, 25, 60, 0.9) 0%,
        rgba(30, 64, 175, 0.7) 30%,
        rgba(30, 64, 175, 0.4) 70%,
        rgba(10, 25, 60, 0.9) 100%
    );
    z-index: 0;
}

/* Glass-morphism content card */
.hero-content {
    position: relative;
    z-index: 1;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border-radius: 24px;
    padding: 50px 40px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    max-width: 800px;
    margin: 0 auto;
}

.hero-content h1 {
    font-size: 3.2rem;
    font-weight: 900;
    color: white;
    margin-bottom: 20px;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    background: linear-gradient(135deg, #ffffff 0%, #e0e7ff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.hero-content .subtitle {
    font-size: 1.3rem;
    color: rgba(255, 255, 255, 0.95);
    margin-bottom: 30px;
    line-height: 1.6;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}

.hero-buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}

.hero-btn {
    padding: 14px 32px;
    border-radius: 50px;
    font-weight: 600;
    font-size: 1rem;
    transition: all 0.3s ease;
    border: 2px solid transparent;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.hero-btn-primary {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
}

.hero-btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(59, 130, 246, 0.6);
    border-color: rgba(255, 255, 255, 0.3);
}

.hero-btn-secondary {
    background: rgba(255, 255, 255, 0.15);
    color: white;
    backdrop-filter: blur(5px);
    border: 2px solid rgba(255, 255, 255, 0.3);
}

.hero-btn-secondary:hover {
    background: rgba(255, 255, 255, 0.25);
    transform: translateY(-3px);
    border-color: rgba(255, 255, 255, 0.5);
}

/* Campus info overlay */
.campus-info {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(10px);
    padding: 12px 25px;
    border-radius: 50px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
    font-size: 0.9rem;
}

.campus-info i {
    color: #60a5fa;
}

.video-controls {
    position: absolute;
    top: 30px;
    right: 30px;
    z-index: 2;
}

.video-toggle {
    background: rgba(0, 0, 0, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
    border-radius: 50%;
    width: 45px;
    height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    backdrop-filter: blur(5px);
}

.video-toggle:hover {
    background: rgba(30, 64, 175, 0.8);
    transform: scale(1.1);
}

/* Content sections styling to match the theme */
.container {
    position: relative;
    z-index: 2;
}

/* ============================================================
   NIGHT-THEMED FEATURE CARDS
   ============================================================ */
.feature-section-title {
    color: #1e293b;
    font-weight: 800;
    text-align: center;
    margin-bottom: 40px;
    position: relative;
    padding-bottom: 15px;
}

.feature-section-title::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 2px;
}

.feature-card {
    padding: 32px 24px;
    border-radius: 20px;
    background: white;
    border: 1px solid #e2e8f0;
    transition: all 0.4s ease;
    height: 100%;
    position: relative;
    overflow: hidden;
}

.feature-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #1e40af);
    border-radius: 20px 20px 0 0;
}

.feature-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(30, 64, 175, 0.15);
    border-color: #3b82f6;
}

.feature-icon {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, #f0f9ff, #dbeafe);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    color: #1e40af;
    font-size: 28px;
    transition: transform 0.3s ease;
}

.feature-card:hover .feature-icon {
    transform: scale(1.1);
}

.feature-card h5 {
    color: #1e293b;
    font-weight: 700;
    margin-bottom: 15px;
}

.feature-card p {
    color: #64748b;
    line-height: 1.6;
}

/* ============================================================
   CTA SECTION - UPDATED
   ============================================================ */
.cta-section {
    background: linear-gradient(135deg, #1e293b, #0f172a);
    padding: 70px 0;
    border-radius: 32px;
    margin-top: 60px;
    color: white;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.cta-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,50 Q250,0 500,50 T1000,50 V100 H0 Z" fill="rgba(59,130,246,0.1)"/></svg>');
    background-size: cover;
}

.cta-section h4 {
    font-size: 2.2rem;
    font-weight: 800;
    margin-bottom: 20px;
    color: white;
}

.cta-section p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.1rem;
    max-width: 600px;
    margin: 0 auto 35px;
}

.cta-buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
    flex-wrap: wrap;
}

.btn-glow {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    border: none;
    padding: 14px 32px;
    border-radius: 50px;
    font-weight: 600;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
}

.btn-glow:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 30px rgba(59, 130, 246, 0.6);
    color: white;
}

.btn-outline-light {
    background: rgba(255, 255, 255, 0.1);
    border: 2px solid rgba(255, 255, 255, 0.3);
    color: white;
    backdrop-filter: blur(5px);
}

.btn-outline-light:hover {
    background: rgba(255, 255, 255, 0.2);
    border-color: white;
    color: white;
}

/* Footer */
.home-footer {
    margin-top: 60px;
    padding: 20px;
    color: #64748b;
    border-top: 1px solid #e2e8f0;
}
</style>

<!-- ============================================================
     HERO SECTION WITH AERIAL FOOTAGE
     ============================================================ -->
<section class="hero-section">
    <!-- Video Background -->
    <div class="video-background">
        <video id="uthmVideo" autoplay muted loop playsinline>
            <source src="<?= base_url('images/uthm-aerial.mp4') ?>" type="video/mp4">
            <source src="<?= base_url('images/uthm-aerial.webm') ?>" type="video/webm">
        </video>
    </div>
    
    <!-- Overlay for better text readability -->
    <div class="hero-overlay"></div>
    
    <!-- Video Controls -->
    <div class="video-controls">
        <button class="video-toggle" id="videoPauseBtn" title="Pause Video">
            <i class="bi bi-pause-fill"></i>
        </button>
    </div>
    
    <!-- Hero Content -->
    <div class="container">
        <div class="hero-content">
            <h1>FKMP Smart Laboratory Management System</h1>
            <p class="subtitle">
                Experience UTHM's state-of-the-art facilities. Book laboratories, manage equipment, 
                and streamline lab usage efficiently — all in one place.
            </p>
            <div class="hero-buttons">
                <a href="<?= site_url('/laboratories') ?>" class="hero-btn hero-btn-secondary">
                    <i class="bi bi-building"></i>
                    Explore Laboratories
                </a>
                <a href="<?= site_url('/login') ?>" class="hero-btn hero-btn-primary">
                    <i class="bi bi-box-arrow-in-right"></i>
                    Login to SLAMS
                </a>
            </div>
        </div>
    </div>
    
    <!-- Campus Info -->
    <div class="campus-info">
        <i class="bi bi-camera-video-fill"></i>
        <span>UTHM Campus • Night Aerial Footage</span>
    </div>
</section>


<div class="container">

    <!-- ============================================================
         FEATURE SECTION
         ============================================================ -->
    <h3 class="feature-section-title">Why Use SLAMS?</h3>

    <div class="row g-4 mb-5">

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="bi bi-calendar-check"></i>
                </div>
                <h5 class="fw-semibold">Fast & Easy Booking</h5>
                <p class="small mb-0">
                    A streamlined wizard helps UTHM students and staff submit lab bookings with ease.
                </p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="bi bi-tools"></i>
                </div>
                <h5 class="fw-semibold">Equipment Availability</h5>
                <p class="small mb-0">
                    View real-time equipment availability and select items required for your task.
                </p>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="bi bi-shield-check"></i>
                </div>
                <h5 class="fw-semibold">Secure Approval Flow</h5>
                <p class="small mb-0">
                    Built-in PIC and Manager approval ensures compliance and lab safety.
                </p>
            </div>
        </div>

    </div>


    <!-- ============================================================
         CTA SECTION
         ============================================================ -->
    <section class="cta-section">
        <h4 class="fw-bold mb-3">Ready to get started?</h4>
        <p class="mb-4">
            Log in to submit a booking request or explore our available laboratories at UTHM.
        </p>
        <div class="cta-buttons">
            <a href="<?= site_url('/login') ?>" class="btn btn-glow px-4 py-2">
                <i class="bi bi-person-circle me-1"></i> Login Now
            </a>
            <a href="<?= site_url('/laboratories') ?>" class="btn btn-outline-light px-4 py-2">
                Browse Laboratories
            </a>
        </div>
    </section>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('uthmVideo');
    const videoBtn = document.getElementById('videoPauseBtn');
    const videoIcon = videoBtn.querySelector('i');
    let isPlaying = true;
    
    // Optimize video for night footage
    if (video) {
        // Adjust video settings for night footage
        video.style.filter = 'brightness(0.8) contrast(1.2) saturate(1.1)';
        
        // Ensure video plays
        video.play().catch(error => {
            console.log('Autoplay prevented, showing play button');
            videoBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
            isPlaying = false;
        });
        
        // Video controls
        videoBtn.addEventListener('click', function() {
            if (isPlaying) {
                video.pause();
                videoIcon.className = 'bi bi-play-fill';
                videoBtn.title = 'Play Video';
                isPlaying = false;
            } else {
                video.play();
                videoIcon.className = 'bi bi-pause-fill';
                videoBtn.title = 'Pause Video';
                isPlaying = true;
            }
        });
        
        // Add subtle parallax effect on scroll
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const rate = scrolled * 0.1;
            video.style.transform = `translateY(${rate}px)`;
        });
        
        // Handle video loading states
        video.addEventListener('waiting', function() {
            video.style.opacity = '0.8';
        });
        
        video.addEventListener('canplay', function() {
            video.style.opacity = '1';
        });
        
        // Restart video when it ends
        video.addEventListener('ended', function() {
            this.currentTime = 0;
            this.play();
        });
    }
    
    // Add smooth scroll for navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId !== '#') {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
});
</script>

<?= $this->endSection() ?>