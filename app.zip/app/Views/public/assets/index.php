<?= $this->extend('layouts/main_user') ?>
<?= $this->section('content') ?>

<style>
    .asset-card {
        border-radius: 14px;
        border: 1px solid #e2e8f0;
        transition: 0.2s ease;
    }
    .asset-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 22px rgba(15,23,42,0.12);
    }
    .asset-pill {
        font-size: 0.75rem;
        padding: 2px 8px;
        border-radius: 999px;
        background: #e0f2fe;
        color: #0369a1;
    }
</style>

<div class="container py-4">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h2 class="fw-bold text-primary mb-1">Laboratory Equipment</h2>
            <p class="text-muted mb-0 small">
                Browse equipment available across FKMP laboratories.
            </p>
        </div>

        <form method="get" class="d-flex gap-2" style="max-width: 320px;">
            <input type="text"
                   name="q"
                   value="<?= esc($search ?? '') ?>"
                   class="form-control form-control-sm"
                   placeholder="Search equipment or lab...">
            <button class="btn btn-sm btn-primary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>

    <?php if (! empty($search)): ?>
        <div class="alert alert-info py-2 small border-0 mb-3">
            Showing results for: <strong><?= esc($search) ?></strong>
            <a href="<?= site_url('/assets') ?>" class="ms-2">Clear</a>
        </div>
    <?php endif; ?>

    <?php if (empty($assets)): ?>
        <div class="text-center text-muted py-5">
            <i class="bi bi-hdd fs-1 mb-2"></i>
            <p class="mb-0">No equipment found.</p>
        </div>
    <?php else: ?>

        <div class="row g-3">
            <?php foreach ($assets as $asset): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card asset-card h-100 shadow-sm border-0">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="fw-semibold mb-0 text-primary">
                                    <?= esc($asset['name']) ?>
                                </h5>
                                <span class="asset-pill">
                                    Qty: <?= esc($asset['quantity'] ?? 0) ?>
                                </span>
                            </div>

                            <?php if (! empty($asset['description'])): ?>
                                <p class="small text-muted mb-2">
                                    <?= esc($asset['description']) ?>
                                </p>
                            <?php endif; ?>

                            <div class="small text-muted">
                                <i class="bi bi-building me-1"></i>
                                <?= esc($asset['lab_name'] ?? 'Unknown Lab') ?>
                                <?php if (! empty($asset['lab_room'])): ?>
                                    · Room <?= esc($asset['lab_room']) ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

</div>

<?= $this->endSection() ?>
