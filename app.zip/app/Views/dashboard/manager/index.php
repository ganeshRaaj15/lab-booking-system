<?= $this->extend('layouts/main_user') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold text-primary mb-0">Lab Manager Dashboard</h2>
        <p class="text-muted small">Comprehensive overview and management tools for all laboratories.</p>
    </div>
</div>

<!-- QUICK STATS CARDS -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card stats-card bg-white border shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-muted small fw-semibold text-uppercase">Total Bookings</div>
                        <div class="fs-3 fw-bold text-primary"><?= esc($stats['total']) ?></div>
                    </div>
                    <i class="bi bi-calendar-check fs-2 text-primary opacity-75"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card stats-card bg-white border shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-muted small fw-semibold text-uppercase">This Week</div>
                        <div class="fs-3 fw-bold text-success"><?= esc($stats['currentWeek']) ?></div>
                        <div class="small <?= $stats['weekGrowth'] >= 0 ? 'text-success' : 'text-danger' ?>">
                            <i class="bi bi-arrow-<?= $stats['weekGrowth'] >= 0 ? 'up' : 'down' ?> me-1"></i>
                            <?= abs($stats['weekGrowth']) ?>%
                        </div>
                    </div>
                    <i class="bi bi-graph-up-arrow fs-2 text-success opacity-75"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card stats-card bg-white border shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-muted small fw-semibold text-uppercase">Pending Approval</div>
                        <div class="fs-3 fw-bold text-warning"><?= esc($stats['pendingManager']) ?></div>
                        <div class="small text-muted">Non-FKMP bookings</div>
                    </div>
                    <i class="bi bi-clipboard-check fs-2 text-warning opacity-75"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card stats-card bg-white border shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <div class="text-muted small fw-semibold text-uppercase">Faculty Mix</div>
                        <div class="fs-3 fw-bold text-info"><?= esc($stats['fkmp']) ?>/<?= esc($stats['nonFkmp']) ?></div>
                        <div class="small text-muted">FKMP/Non-FKMP</div>
                    </div>
                    <i class="bi bi-people fs-2 text-info opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- TAB NAVIGATION -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white border-bottom-0 pt-3">
        <ul class="nav nav-tabs nav-tabs-custom" id="dashboardTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link <?= $activeTab === 'approvals' ? 'active' : '' ?>" 
                        id="approvals-tab" 
                        data-bs-toggle="tab" 
                        data-bs-target="#approvals" 
                        type="button" 
                        role="tab">
                    <i class="bi bi-clipboard-check me-2"></i>Booking Approvals
                    <?php if ($stats['pendingManager'] > 0): ?>
                        <span class="badge bg-danger ms-2"><?= esc($stats['pendingManager']) ?></span>
                    <?php endif; ?>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link <?= $activeTab === 'metrics' ? 'active' : '' ?>" 
                        id="metrics-tab" 
                        data-bs-toggle="tab" 
                        data-bs-target="#metrics" 
                        type="button" 
                        role="tab">
                    <i class="bi bi-bar-chart me-2"></i>Lab Metrics & Analytics
                </button>
            </li>
        </ul>
    </div>

    <div class="card-body p-0">
        <div class="tab-content" id="dashboardTabsContent">
            
            <!-- TAB 1: BOOKING APPROVALS -->
            <div class="tab-pane fade <?= $activeTab === 'approvals' ? 'show active' : '' ?>" 
                 id="approvals" 
                 role="tabpanel">
                 
                <?php if (empty($pendingMgr)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-check-circle-fill text-success fs-1"></i>
                        <h5 class="mt-3 text-muted">No pending approvals</h5>
                        <p class="text-muted">All non-FKMP bookings have been processed.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="20%">Lab & Date</th>
                                    <th width="15%">Faculty</th>
                                    <th width="15%">PIC</th>
                                    <th width="25%">Assets Requested</th>
                                    <th width="25%" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingMgr as $b): ?>
                                    <tr id="row-mgr-<?= $b['id'] ?>">
                                        <td>
                                            <div class="fw-semibold"><?= esc($b['lab_name']) ?></div>
                                            <div class="text-muted small">
                                                <?= esc($b['date']) ?> • 
                                                <?= esc($b['start_time']) ?>-<?= esc($b['end_time']) ?>
                                            </div>
                                            <div class="text-muted small">Room <?= esc($b['lab_room']) ?></div>
                                        </td>
                                        
                                        <td>
                                            <span class="badge bg-info"><?= esc($b['faculty_name'] ?? 'Other') ?></span>
                                        </td>
                                        
                                        <td>
                                            <div class="small"><?= esc($b['pic_name'] ?? 'N/A') ?></div>
                                            <div class="text-muted x-small"><?= esc($b['pic_email'] ?? '') ?></div>
                                        </td>
                                        
                                        <td>
                                            <?php if (!empty($b['assets'])): ?>
                                                <div class="d-flex flex-wrap gap-1">
                                                    <?php foreach ($b['assets'] as $asset): ?>
                                                        <span class="badge bg-light text-dark border">
                                                            <?= esc($asset['name']) ?> (×<?= $asset['quantity_used'] ?>)
                                                        </span>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted small">No assets</span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-end">
    <div class="d-flex flex-column flex-md-row gap-2 justify-content-end">
        <div class="d-flex gap-1">
            <button class="btn btn-outline-primary btn-sm"
                    onclick="viewBookingDetails(<?= $b['id'] ?>)"
                    data-bs-toggle="tooltip" title="View Full Details">
                <i class="bi bi-eye me-1"></i>View
            </button>
        </div>
        <div class="d-flex gap-1">
            <button class="btn btn-success btn-sm"
                    onclick="approveBooking(<?= $b['id'] ?>)"
                    data-bs-toggle="tooltip" title="Approve Booking">
                <i class="bi bi-check-lg me-1"></i>Approve
            </button>
            <button class="btn btn-danger btn-sm"
                    onclick="rejectBooking(<?= $b['id'] ?>)"
                    data-bs-toggle="tooltip" title="Reject Booking">
                <i class="bi bi-x-lg me-1"></i>Reject
            </button>
        </div>
    </div>
</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- TAB 2: LAB METRICS & ANALYTICS -->
            <!-- TAB 2: LAB METRICS & ANALYTICS -->
<div class="tab-pane fade <?= $activeTab === 'metrics' ? 'show active' : '' ?>" 
     id="metrics" 
     role="tabpanel">
     
    <div class="p-4">
        
        <!-- SECTION 1: QUICK INSIGHTS CARDS -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card border-0 bg-gradient-primary text-white shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <div class="small opacity-75">Avg. Weekly Utilization</div>
                                <div class="fs-4 fw-bold">
                                    <?php 
                                    $avgUtil = array_column($analytics['weeklyUtilization'], 'avg_utilization');
                                    echo count($avgUtil) > 0 ? round(array_sum($avgUtil) / count($avgUtil), 1) : 0;
                                    ?>%
                                </div>
                            </div>
                            <i class="bi bi-speedometer2 fs-2 opacity-75"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card border-0 bg-gradient-success text-white shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <div class="small opacity-75">Peak Hour</div>
                                <div class="fs-4 fw-bold">
                                    <?php 
                                    if (!empty($analytics['peakHours']['timeSlots'])) {
                                        $peak = max(array_column($analytics['peakHours']['timeSlots'], 'booking_count'));
                                        $peakHour = $analytics['peakHours']['timeSlots'][array_search($peak, array_column($analytics['peakHours']['timeSlots'], 'booking_count'))]['hour_label'];
                                        echo $peakHour;
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </div>
                            </div>
                            <i class="bi bi-clock-history fs-2 opacity-75"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card border-0 bg-gradient-info text-white shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <div class="small opacity-75">Busiest Day</div>
                                <div class="fs-4 fw-bold">
                                    <?php 
                                    if (!empty($analytics['peakHours']['busyDays'])) {
                                        echo $analytics['peakHours']['busyDays'][0]['day'] ?? 'N/A';
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </div>
                            </div>
                            <i class="bi bi-calendar-event fs-2 opacity-75"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card border-0 bg-gradient-warning text-white shadow-sm">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <div class="small opacity-75">Top Faculty</div>
                                <div class="fs-4 fw-bold">
                                    <?php 
                                    if (!empty($analytics['facultyDistribution'])) {
                                        echo $analytics['facultyDistribution'][0]['faculty'] ?? 'N/A';
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </div>
                            </div>
                            <i class="bi bi-trophy fs-2 opacity-75"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SECTION 2: WEEKLY UTILIZATION & PEAK HOURS -->
        <div class="row mb-4">
            <!-- Weekly Utilization Chart -->
            <div class="col-lg-8">
                <div class="card border h-100">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h6 class="fw-semibold mb-0">
                            <i class="bi bi-calendar-week me-2"></i>Weekly Utilization Trend
                        </h6>
                        <div class="small text-muted">Last 8 weeks</div>
                    </div>
                    <div class="card-body">
                        <canvas id="weeklyUtilizationChart" height="150"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Peak Hours Pie Chart -->
            <div class="col-lg-4">
                <div class="card border h-100">
                    <div class="card-header bg-light">
                        <h6 class="fw-semibold mb-0">
                            <i class="bi bi-pie-chart me-2"></i>Peak Hours Distribution
                        </h6>
                    </div>
                    <div class="card-body">
                        <canvas id="peakHoursPieChart" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SECTION 3: FACULTY & ASSET DISTRIBUTION -->
        <div class="row mb-4">
            <!-- Faculty Distribution Pie Chart -->
            <div class="col-md-6">
                <div class="card border h-100">
                    <div class="card-header bg-light">
                        <h6 class="fw-semibold mb-0">
                            <i class="bi bi-people me-2"></i>Faculty Distribution
                        </h6>
                    </div>
                    <div class="card-body">
                        <canvas id="facultyPieChart" height="250"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- Asset Usage Radar Chart -->
            <div class="col-md-6">
                <div class="card border h-100">
                    <div class="card-header bg-light">
                        <h6 class="fw-semibold mb-0">
                            <i class="bi bi-radar me-2"></i>Asset Usage Pattern
                        </h6>
                    </div>
                    <div class="card-body">
                        <canvas id="assetRadarChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- SECTION 4: LAB PERFORMANCE TABLE -->
        <div class="card border mb-4">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h6 class="fw-semibold mb-0">
                    <i class="bi bi-building me-2"></i>Lab Performance Dashboard
                </h6>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-primary">Total</span>
                    <span class="badge bg-success">Approved</span>
                    <span class="badge bg-warning">Pending</span>
                    <span class="badge bg-danger">Rejected</span>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Laboratory</th>
                                <th class="text-center">PIC</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Weekly Util.</th>
                                <th class="text-center">Trend</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($analytics['labPerformance'] as $lab): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold"><?= esc($lab['name']) ?></div>
                                        <small class="text-muted">Room <?= esc($lab['room']) ?></small>
                                    </td>
                                    <td class="text-center">
                                        <small><?= esc($lab['pic_name']) ?></small>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center gap-1">
                                            <span class="badge bg-primary" data-bs-toggle="tooltip" title="Total"><?= esc($lab['total']) ?></span>
                                            <span class="badge bg-success" data-bs-toggle="tooltip" title="Approved"><?= esc($lab['approved']) ?></span>
                                            <span class="badge bg-warning" data-bs-toggle="tooltip" title="Pending"><?= esc($lab['pending']) ?></span>
                                            <span class="badge bg-danger" data-bs-toggle="tooltip" title="Rejected"><?= esc($lab['rejected']) ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="fw-semibold <?= $lab['weekly_utilization'] > 60 ? 'text-success' : ($lab['weekly_utilization'] > 30 ? 'text-warning' : 'text-info') ?>">
                                                <?= round($lab['weekly_utilization'], 0) ?>%
                                            </div>
                                            <div class="progress" style="height: 4px; width: 80px;">
                                                <div class="progress-bar bg-<?= $lab['weekly_utilization'] > 60 ? 'success' : ($lab['weekly_utilization'] > 30 ? 'warning' : 'info') ?>"
                                                     role="progressbar" 
                                                     style="width: <?= min(100, $lab['weekly_utilization']) ?>%">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($lab['weekly_utilization'] > 60): ?>
                                            <i class="bi bi-arrow-up-circle-fill text-success fs-5" data-bs-toggle="tooltip" title="High Usage"></i>
                                        <?php elseif ($lab['weekly_utilization'] > 30): ?>
                                            <i class="bi bi-dash-circle-fill text-warning fs-5" data-bs-toggle="tooltip" title="Moderate Usage"></i>
                                        <?php else: ?>
                                            <i class="bi bi-arrow-down-circle-fill text-info fs-5" data-bs-toggle="tooltip" title="Low Usage"></i>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- SECTION 5: MONTHLY TRENDS -->
        <div class="card border">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h6 class="fw-semibold mb-0">
                    <i class="bi bi-graph-up-arrow me-2"></i>Monthly Booking Trends
                </h6>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-primary active" onclick="updateTrendChart('line')">Line</button>
                    <button type="button" class="btn btn-outline-primary" onclick="updateTrendChart('bar')">Bar</button>
                    <button type="button" class="btn btn-outline-primary" onclick="updateTrendChart('area')">Area</button>
                </div>
            </div>
            <div class="card-body">
                <canvas id="monthlyTrendsChart" height="150"></canvas>
            </div>
        </div>
        
    </div>
</div>
        </div>
    </div>
</div>

<!-- MODAL FOR BOOKING DETAILS -->
<div class="modal fade" id="bookingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Booking Details - Manager Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="bookingDetails">
                <!-- Content loaded via AJAX -->
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="btnRejectModal" onclick="rejectBookingModal()">
                    <i class="bi bi-x-lg me-1"></i>Reject
                </button>
                <button type="button" class="btn btn-success" id="btnApproveModal" onclick="approveBookingModal()">
                    <i class="bi bi-check-lg me-1"></i>Approve
                </button>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
let currentBookingId = null;

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Initialize charts if on metrics tab
    if (document.getElementById('metrics').classList.contains('active')) {
        initializeCharts();
    }
    
    // Listen for tab changes to initialize charts
    document.getElementById('metrics-tab').addEventListener('shown.bs.tab', function() {
        initializeCharts();
    });
});

// Add this to your initializeCharts() function or create a new function
function initializeEnhancedCharts() {
    // Weekly Utilization Chart (Line)
    const weeklyCtx = document.getElementById('weeklyUtilizationChart').getContext('2d');
    new Chart(weeklyCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($analytics['weeklyUtilization'], 'week_label')) ?>,
            datasets: [{
                label: 'Utilization %',
                data: <?= json_encode(array_column($analytics['weeklyUtilization'], 'avg_utilization')) ?>,
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                tension: 0.4,
                fill: true,
                borderWidth: 3,
                pointBackgroundColor: '#3b82f6',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Utilization: ' + context.parsed.y + '%';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                }
            }
        }
    });
    
    // Peak Hours Pie Chart
    const peakPieCtx = document.getElementById('peakHoursPieChart').getContext('2d');
    const peakLabels = <?= json_encode(array_column($analytics['peakHours']['timeSlots'], 'hour_label')) ?>;
    const peakData = <?= json_encode(array_column($analytics['peakHours']['timeSlots'], 'booking_count')) ?>;
    
    // Generate vibrant colors for pie chart
    const peakColors = peakLabels.map((_, index) => {
        const hue = (index * 40) % 360;
        return `hsl(${hue}, 70%, 60%)`;
    });
    
    new Chart(peakPieCtx, {
        type: 'doughnut',
        data: {
            labels: peakLabels,
            datasets: [{
                data: peakData,
                backgroundColor: peakColors,
                borderColor: '#fff',
                borderWidth: 2,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        padding: 15,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((context.parsed / total) * 100);
                            return `${context.label}: ${context.parsed} bookings (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    // Faculty Distribution Pie Chart
    const facultyCtx = document.getElementById('facultyPieChart').getContext('2d');
    const facultyLabels = <?= json_encode(array_column($analytics['facultyDistribution'], 'faculty')) ?>;
    const facultyData = <?= json_encode(array_column($analytics['facultyDistribution'], 'count')) ?>;
    
    // Color faculty by FKMP status
    const facultyColors = <?= json_encode(array_column($analytics['facultyDistribution'], 'is_fkmp')) ?>.map(isFkmp => 
        isFkmp == 1 ? '#10b981' : '#3b82f6'
    );
    
    new Chart(facultyCtx, {
        type: 'pie',
        data: {
            labels: facultyLabels,
            datasets: [{
                data: facultyData,
                backgroundColor: facultyColors,
                borderColor: '#fff',
                borderWidth: 2,
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        boxWidth: 12,
                        padding: 15,
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((context.parsed / total) * 100);
                            const isFkmp = <?= json_encode(array_column($analytics['facultyDistribution'], 'is_fkmp')) ?>[context.dataIndex];
                            const type = isFkmp == 1 ? ' (FKMP)' : ' (Non-FKMP)';
                            return `${context.label}${type}: ${context.parsed} bookings (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    // Asset Usage Radar Chart
    const assetCtx = document.getElementById('assetRadarChart').getContext('2d');
    const assetLabels = <?= json_encode(array_column($analytics['assetUsage']['mostUsed'], 'name')) ?>;
    const assetData = <?= json_encode(array_column($analytics['assetUsage']['mostUsed'], 'total_used')) ?>;
    
    // Normalize data for radar chart (0-100 scale)
    const maxAssetUsage = Math.max(...assetData);
    const normalizedAssetData = assetData.map(value => (value / maxAssetUsage) * 100);
    
    new Chart(assetCtx, {
        type: 'radar',
        data: {
            labels: assetLabels,
            datasets: [{
                label: 'Usage Level',
                data: normalizedAssetData,
                backgroundColor: 'rgba(245, 158, 11, 0.2)',
                borderColor: '#f59e0b',
                pointBackgroundColor: '#f59e0b',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: '#f59e0b',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        display: false
                    },
                    pointLabels: {
                        font: {
                            size: 11
                        }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const index = context.dataIndex;
                            const actualValue = assetData[index];
                            return `${assetLabels[index]}: ${actualValue} times used`;
                        }
                    }
                }
            }
        }
    });
    
    // Monthly Trends Chart (with toggle)
    initializeTrendChart('line');
}

let trendChart = null;

function initializeTrendChart(type = 'line') {
    const monthlyCtx = document.getElementById('monthlyTrendsChart').getContext('2d');
    
    if (trendChart) {
        trendChart.destroy();
    }
    
    const isArea = type === 'area';
    
    trendChart = new Chart(monthlyCtx, {
        type: isArea ? 'line' : type,
        data: {
            labels: <?= json_encode(array_column($analytics['monthlyTrends'], 'month')) ?>,
            datasets: [{
                label: 'Bookings',
                data: <?= json_encode(array_column($analytics['monthlyTrends'], 'total')) ?>,
                borderColor: '#8b5cf6',
                backgroundColor: isArea ? 'rgba(139, 92, 246, 0.3)' : (type === 'bar' ? '#8b5cf6' : 'transparent'),
                tension: 0.3,
                fill: isArea,
                borderWidth: type === 'bar' ? 0 : 3,
                borderRadius: type === 'bar' ? 5 : 0,
                hoverBackgroundColor: type === 'bar' ? '#7c3aed' : undefined
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                }
            }
        }
    });
}

function updateTrendChart(type) {
    initializeTrendChart(type);
    
    // Update button states
    document.querySelectorAll('#metrics .btn-group-sm .btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
}

// Update your existing initializeCharts() function
function initializeCharts() {
    initializeEnhancedCharts();
    
    // Initialize tooltips for badges
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Booking functions (same as before)
function viewBookingDetails(id) {
    currentBookingId = id;
    const modal = new bootstrap.Modal(document.getElementById('bookingModal'));
    
    document.getElementById('bookingDetails').innerHTML = `
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    fetch(`/dashboard/manager/booking/${id}`)
        .then(r => r.json())
        .then(data => {
            if (data.status === 'success') {
                displayBookingDetails(data.booking);
                modal.show();
            } else {
                alert(data.message);
                modal.hide();
            }
        });
}

function displayBookingDetails(booking) {
    const container = document.getElementById('bookingDetails');
    
    // Assets list
    let assetsHtml = '<p class="text-muted mb-0">No assets selected</p>';
    if (booking.assets && booking.assets.length > 0) {
        assetsHtml = '<div class="row g-2">';
        booking.assets.forEach(asset => {
            assetsHtml += `
                <div class="col-md-6">
                    <div class="card border">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center">
                                <div>
                                    <h6 class="mb-0">${asset.name}</h6>
                                    <small class="text-muted">Quantity: ${asset.quantity_used}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        assetsHtml += '</div>';
    }
    
    // PDF link
    let pdfHtml = '';
    if (booking.pdf_url) {
        pdfHtml = `
            <div class="mt-3">
                <a href="${booking.pdf_url}" target="_blank" class="btn btn-outline-primary btn-sm">
                    <i class="bi bi-file-pdf me-1"></i>View Uploaded PDF
                </a>
            </div>
        `;
    }
    
    const isFkmp = booking.is_fkmp == 1;
    
    container.innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <div class="card border mb-3">
                    <div class="card-body">
                        <h6 class="fw-semibold">Laboratory Information</h6>
                        <p class="mb-2"><strong>Lab:</strong> ${booking.lab_name}</p>
                        <p class="mb-2"><strong>Room:</strong> ${booking.lab_room}</p>
                        <p class="mb-2"><strong>PIC:</strong> ${booking.pic_name}</p>
                        <p class="mb-0"><strong>PIC Email:</strong> ${booking.pic_email}</p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card border mb-3">
                    <div class="card-body">
                        <h6 class="fw-semibold">Booking Details</h6>
                        <p class="mb-2"><strong>Date:</strong> ${booking.date}</p>
                        <p class="mb-2"><strong>Time:</strong> ${booking.start_time} - ${booking.end_time}</p>
                        <p class="mb-2"><strong>Faculty:</strong> ${booking.faculty_name}</p>
                        <p class="mb-2">
                            <strong>Type:</strong> 
                            <span class="badge ${isFkmp ? 'bg-success' : 'bg-info'}">
                                ${isFkmp ? 'FKMP' : 'Non-FKMP'}
                            </span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card border mb-3">
            <div class="card-body">
                <h6 class="fw-semibold">Activity Description</h6>
                <p>${booking.activity}</p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <h6 class="fw-semibold">Requested Assets</h6>
                <div class="card border mb-3">
                    <div class="card-body">
                        ${assetsHtml}
                    </div>
                </div>
            </div>
        </div>
        
        ${pdfHtml}
        
        ${!isFkmp ? `
        <div class="alert alert-info mt-3">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Manager Approval Required:</strong> This booking is from a Non-FKMP student.
        </div>
        ` : ''}
    `;
}

function approveBookingModal() {
    if (currentBookingId) {
        approveBooking(currentBookingId);
        bootstrap.Modal.getInstance(document.getElementById('bookingModal')).hide();
    }
}

function rejectBookingModal() {
    if (currentBookingId) {
        rejectBooking(currentBookingId);
        bootstrap.Modal.getInstance(document.getElementById('bookingModal')).hide();
    }
}

function approveBooking(id) {
    if (!confirm("Approve this booking?")) return;

    fetch(`/booking/approve/${id}`, {
        method:"POST",
        headers: {"X-Requested-With":"XMLHttpRequest"}
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === "success") {
            document.getElementById(`row-mgr-${id}`).remove();
            
            // Update badge count
            const badge = document.querySelector('#approvals-tab .badge');
            if (badge) {
                const currentCount = parseInt(badge.textContent);
                if (currentCount > 1) {
                    badge.textContent = currentCount - 1;
                } else {
                    badge.remove();
                }
            }
            
            // If no more pending, show message
            if (document.querySelectorAll('tbody tr').length === 0) {
                document.querySelector('#approvals').innerHTML = `
                    <div class="text-center py-5">
                        <i class="bi bi-check-circle-fill text-success fs-1"></i>
                        <h5 class="mt-3 text-muted">No pending approvals</h5>
                        <p class="text-muted">All non-FKMP bookings have been processed.</p>
                    </div>
                `;
            }
        } else {
            alert(data.message);
        }
    });
}

function rejectBooking(id) {
    if (!confirm("Reject this booking?")) return;

    fetch(`/booking/reject/${id}`, {
        method:"POST",
        headers: {"X-Requested-With":"XMLHttpRequest"}
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === "success") {
            document.getElementById(`row-mgr-${id}`).remove();
            
            // Update badge count
            const badge = document.querySelector('#approvals-tab .badge');
            if (badge) {
                const currentCount = parseInt(badge.textContent);
                if (currentCount > 1) {
                    badge.textContent = currentCount - 1;
                } else {
                    badge.remove();
                }
            }
        } else {
            alert(data.message);
        }
    });
}
</script>

<style>
.stats-card {
    border-radius: 10px;
    transition: transform 0.2s;
}
.stats-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
}

.nav-tabs-custom .nav-link {
    border: none;
    color: #6c757d;
    font-weight: 500;
    padding: 0.75rem 1.5rem;
    position: relative;
}
.nav-tabs-custom .nav-link.active {
    color: #3b82f6;
    background: transparent;
    border-bottom: 3px solid #3b82f6;
}
.nav-tabs-custom .nav-link:not(.active):hover {
    color: #3b82f6;
}

.table th {
    font-weight: 600;
    font-size: 0.85rem;
    color: #6c757d;
    border-top: none;
}

.card {
    border: 1px solid #e9ecef;
    border-radius: 10px;
}

.card-header.bg-light {
    background-color: #f8f9fa !important;
    border-bottom: 1px solid #e9ecef;
}

.progress {
    border-radius: 10px;
}

.modal-content {
    border-radius: 12px;
}

.badge {
    font-weight: 500;
}

.list-group-item {
    border-color: rgba(0,0,0,0.05);
}

/* Add to your existing styles */
.bg-gradient-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; }
.bg-gradient-success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%) !important; }
.bg-gradient-info { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%) !important; }
.bg-gradient-warning { background: linear-gradient(135deg, #f7971e 0%, #ffd200 100%) !important; }

.card {
    border: 1px solid #e9ecef;
    border-radius: 12px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    transition: transform 0.2s, box-shadow 0.2s;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.progress {
    border-radius: 10px;
}

.btn-outline-primary {
    border-width: 2px;
}

.badge {
    font-weight: 500;
    padding: 0.35em 0.65em;
}

.table-hover tbody tr:hover {
    background-color: rgba(59, 130, 246, 0.05);
}

.nav-tabs-custom .nav-link {
    border-bottom: 3px solid transparent;
    transition: all 0.3s;
}

.nav-tabs-custom .nav-link.active {
    border-bottom-color: #3b82f6;
    font-weight: 600;
}
</style>

<?= $this->endSection() ?>