<?= $this->extend('layouts/main_user'); ?>
<?= $this->section('content'); ?>

<style>
.auth-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 75vh;
    padding: 20px;
}

.auth-card {
    width: 100%;
    max-width: 480px;
    background: var(--gray-card);
    padding: 2rem;
    border-radius: 18px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
    border-top: 8px solid var(--blue-primary);
}

.auth-title {
    color: var(--blue-primary);
    font-weight: 700;
    text-align: center;
}

.btn-fkmp-auth {
    background: var(--blue-primary);
    color: #fff;
    border-radius: 10px;
    padding: 10px;
    width: 100%;
    font-weight: 600;
    border: none;
}

.btn-fkmp-auth:hover {
    background: var(--blue-light);
    color: #fff;
}
</style>


<div class="auth-wrapper">
    <div class="auth-card">

        <h3 class="auth-title mb-1">Magic Link Login</h3>
        <p class="text-center text-secondary small mb-4">
            Enter your email to receive a login link.
        </p>

        <?php if (session()->has('error')): ?>
            <div class="alert alert-danger"><?= session('error') ?></div>
        <?php endif; ?>

        <form action="<?= url_to('magic-link') ?>" method="post">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label small fw-semibold">Email Address</label>
                <input type="email" name="email" class="form-control form-control-lg"
                       placeholder="you@example.com" required>
            </div>

            <button type="submit" class="btn btn-fkmp-auth mb-3">
                <i class="bi bi-envelope-paper me-1"></i> Send Magic Link
            </button>

            <p class="text-center small">
                <a href="<?= url_to('login') ?>">Back to login</a>
            </p>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>
