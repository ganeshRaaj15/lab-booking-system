<?= $this->extend('layouts/main_user'); ?>
<?= $this->section('content'); ?>

<style>
.auth-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 75vh;
    padding: 20px;
}

.auth-card {
    width: 100%;
    max-width: 480px;
    background: var(--gray-card);
    padding: 2rem;
    border-radius: 18px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
    border-top: 8px solid var(--blue-primary);
}

.auth-title {
    color: var(--blue-primary);
    font-weight: 700;
    text-align: center;
}

/* Updated button theme */
.btn-fkmp-auth {
    background: var(--blue-primary);
    color: #fff;
    border-radius: 10px;
    padding: 10px;
    width: 100%;
    font-weight: 600;
    border: none;
}

.btn-fkmp-auth:hover {
    background: var(--blue-light);
    color:#fff;
}

/* Password field icon fix */
.password-wrapper {
    position: relative;
}

.toggle-password {
    position: absolute;
    top: 70%;
    right: 14px;
    transform: translateY(-50%);
    cursor: pointer;
    color: var(--text-light);
    font-size: 1.25rem;
}

.toggle-password:hover {
    color: var(--blue-light);
}
</style>


<div class="auth-wrapper">
    <div class="auth-card">

        <h3 class="auth-title mb-1">FKMP Smart Lab</h3>
        <p class="text-center text-secondary small mb-4">Login to your account</p>

        <!-- SHOW ERRORS -->
        <?php if (session()->has('error')): ?>
            <div class="alert alert-danger"><?= session('error') ?></div>
        <?php endif; ?>

        <form action="<?= url_to('login') ?>" method="post">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label small fw-semibold">Email Address</label>
                <input type="email" name="email" class="form-control form-control-lg"
                       placeholder="you@example.com" required>
            </div>

            <div class="mb-3 password-wrapper">
                <label class="form-label small fw-semibold">Password</label>
                <input type="password" name="password" id="passwordInput"
                       class="form-control form-control-lg"
                       placeholder="Enter password" required>

                <i class="bi bi-eye-slash toggle-password" id="togglePassword"></i>
            </div>

            <div class="mb-3 d-flex justify-content-between">
                <div>
                    <input type="checkbox" name="remember" id="remember">
                    <label for="remember" class="small">Remember Me</label>
                </div>

                <a class="small text-primary" href="<?= url_to('magic-link') ?>">Magic Link Login</a>
            </div>

            <button type="submit" class="btn btn-fkmp-auth mb-3">
                <i class="bi bi-box-arrow-in-right me-1"></i> Login
            </button>

            <p class="text-center small">
                Don't have an account?
                <a href="<?= url_to('register') ?>">Register here</a>
            </p>
        </form>
    </div>
</div>

<script>
    const togglePassword = document.getElementById("togglePassword");
    const passwordInput = document.getElementById("passwordInput");

    togglePassword.addEventListener("click", function () {
        const isHidden = passwordInput.type === "password";
        passwordInput.type = isHidden ? "text" : "password";

        // Toggle icon
        this.classList.toggle("bi-eye");
        this.classList.toggle("bi-eye-slash");
    });
</script>

<?= $this->endSection(); ?>
