<?= $this->extend('layouts/main_user'); ?>
<?= $this->section('content'); ?>

<style>
.auth-wrapper {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 70vh;
    padding: 20px;
}

.auth-card {
    width: 100%;
    max-width: 480px;
    background: var(--gray-card);
    padding: 2rem;
    border-radius: 18px;
    text-align: center;
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
    border-top: 8px solid var(--blue-primary);
}

.auth-title {
    color: var(--blue-primary);
    font-weight: 700;
}
</style>


<div class="auth-wrapper">
    <div class="auth-card">

        <h3 class="auth-title mb-3">Magic Link Sent</h3>
        <p class="text-secondary small mb-4">
            If the email exists in our system, you will receive a login link shortly.
        </p>

        <i class="bi bi-envelope-check" style="font-size: 3rem; color: var(--fkmp-maroon);"></i>

        <p class="mt-4 small">
            <a href="<?= url_to('login') ?>">Back to login</a>
        </p>

    </div>
</div>

<?= $this->endSection(); ?>
