<footer class="text-center py-4 mt-5" style="color: var(--text-light);">
    <small>
        FKMP Smart Lab Booking System<br>
        © <?= date('Y') ?> Universiti Tun Hussein Onn Malaysia
    </small>
</footer>
