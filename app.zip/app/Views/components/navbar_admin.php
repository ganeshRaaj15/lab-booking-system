<!-- =======================
     ADMIN NAVBAR
======================= -->

<style>
:root {
    --admin-navbar-height: 72px;
    --admin-sidebar-width: 260px;
}

/* ============================================================
   ADMIN GLASS NAVBAR
   ============================================================ */
.admin-glass-navbar {
    position: fixed;
    top: 0;
    left: var(--admin-sidebar-width);
    right: 0;
    height: var(--admin-navbar-height);
    z-index: 980;

    background: linear-gradient(135deg,
        rgba(15, 23, 42, 0.92),
        rgba(30, 41, 59, 0.92)
    );

    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);

    border-bottom: 1px solid rgba(59, 130, 246, 0.25);
    box-shadow: 0 4px 25px rgba(0, 0, 0, 0.35);
}

.navbar-content {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/* Title & Breadcrumb */
.navbar-title h4 {
    margin: 0;
    font-size: 1.4rem;
    font-weight: 700;
    color: white;
}

.breadcrumb-nav {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 2px;
}

.breadcrumb-item {
    font-size: 0.85rem;
    color: rgba(255, 255, 255, 0.7);
    display: flex;
    align-items: center;
    gap: 6px;
}

.breadcrumb-item.active {
    color: #60a5fa;
    font-weight: 500;
}

.breadcrumb-divider {
    color: rgba(255, 255, 255, 0.35);
}

/* Actions */
.navbar-actions {
    display: flex;
    align-items: center;
    gap: 14px;
}

/* User Profile */
.user-profile-glass {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 6px 14px;
    border-radius: 14px;

    background: linear-gradient(135deg,
        rgba(255, 255, 255, 0.08),
        rgba(255, 255, 255, 0.04)
    );

    border: 1px solid rgba(255, 255, 255, 0.15);
    transition: all 0.3s ease;
}

.user-profile-glass:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.25);
}

.user-avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    overflow: hidden;

    background: linear-gradient(135deg,
        rgba(59, 130, 246, 0.3),
        rgba(30, 64, 175, 0.4)
    );

    display: flex;
    align-items: center;
    justify-content: center;
}

.user-avatar i {
    font-size: 1.3rem;
    color: white;
}

.user-info {
    display: flex;
    flex-direction: column;
    line-height: 1.1;
}

.user-name {
    font-size: 0.9rem;
    font-weight: 600;
    color: white;
}

.user-role {
    font-size: 0.75rem;
    color: rgba(255, 255, 255, 0.6);
}

/* Logout */
.btn-logout-glass {
    padding: 8px 18px;
    border-radius: 12px;

    background: linear-gradient(135deg,
        rgba(239, 68, 68, 0.15),
        rgba(220, 38, 38, 0.2)
    );

    color: #fecaca;
    border: 1px solid rgba(248, 113, 113, 0.35);
    font-weight: 600;

    display: flex;
    align-items: center;
    gap: 6px;

    transition: all 0.3s ease;
}

.btn-logout-glass:hover {
    background: linear-gradient(135deg,
        rgba(248, 113, 113, 0.35),
        rgba(239, 68, 68, 0.45)
    );
    color: white;
    transform: translateY(-2px);
}

/* Responsive */
@media (max-width: 992px) {
    .admin-glass-navbar {
        position: sticky;
        left: 0;
        margin-left: 0;
    }
    .user-info {
        display: none;
    }
}

@media (max-width: 768px) {
    .breadcrumb-nav {
        display: none;
    }
    .navbar-title h4 {
        font-size: 1.2rem;
    }
}
</style>

<nav class="admin-glass-navbar">
    <div class="navbar-content px-4">

        <div class="navbar-title">
            <h4><?= esc($page ?? 'Dashboard') ?></h4>

            <div class="breadcrumb-nav">
                <span class="breadcrumb-item">
                    <i class="bi bi-house-door"></i> Dashboard
                </span>

                <?php if (isset($page) && $page !== 'Dashboard'): ?>
                    <span class="breadcrumb-divider">
                        <i class="bi bi-chevron-right"></i>
                    </span>
                    <span class="breadcrumb-item active">
                        <?= esc($page) ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="navbar-actions">
            <?php if (isset($user) && $user): ?>
                <div class="user-profile-glass">
                    <div class="user-avatar">
                        <i class="bi bi-person-circle"></i>
                    </div>
                    <div class="user-info">
                        <div class="user-name"><?= esc($user->username ?? 'User') ?></div>
                        <div class="user-role"><?= esc($user->role ?? 'Administrator') ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <form action="/logout" method="post">
                <?= csrf_field() ?>
                <button class="btn-logout-glass">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </button>
            </form>
        </div>

    </div>
</nav>