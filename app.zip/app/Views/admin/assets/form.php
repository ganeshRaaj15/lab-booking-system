<?= $this->extend('layouts/main_admin') ?>
<?= $this->section('content') ?>

<?php
$isEdit = ($mode === 'edit');
$title  = $isEdit ? 'Edit Asset' : 'Add Asset';
$action = $isEdit
    ? "/admin/assets/update/{$asset['id']}"
    : "/admin/assets/store";
?>

<style>
/* =========================================================
   PAGE BASE
========================================================= */
.assets-form-page {
    --radius-lg: 16px;
    --radius-md: 12px;
    --transition: 0.3s ease;
}

/* =========================================================
   GLASS CARD
========================================================= */
.glass-card {
    background: linear-gradient(135deg,
        rgba(255, 255, 255, 0.95),
        rgba(255, 255, 255, 0.98)
    );
    backdrop-filter: blur(12px);
    border-radius: var(--radius-lg);
    border: 1px solid rgba(59, 130, 246, 0.15);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
    overflow: hidden;
}

/* =========================================================
   HEADER
========================================================= */
.dashboard-header h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: #1e293b;
}

.dashboard-header p {
    color: #64748b;
    font-size: 0.95rem;
}

/* =========================================================
   CARD HEADER
========================================================= */
.settings-card-header {
    background: linear-gradient(
        135deg,
        rgba(59, 130, 246, 0.08),
        rgba(30, 64, 175, 0.05)
    );
    border-bottom: 1px solid rgba(59, 130, 246, 0.12);
    padding: 1.25rem 1.5rem;
}

.settings-card-header h5 {
    margin: 0;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* =========================================================
   FORM GROUP
========================================================= */
.form-group-glass {
    display: flex;
    flex-direction: column;
    gap: 6px;
    transition: var(--transition);
}

.form-group-glass label {
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.form-group-glass label i {
    color: #3b82f6;
}

/* =========================================================
   INPUTS
========================================================= */
.form-control-glass {
    background: rgba(255, 255, 255, 0.92);
    border: 1px solid rgba(59, 130, 246, 0.25);
    border-radius: var(--radius-md);
    padding: 0.75rem 1rem;
    color: #1e293b;
    transition: var(--transition);
}

.form-control-glass:focus {
    background: white;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.12);
    outline: none;
}

.form-control-glass::placeholder {
    color: #94a3b8;
}

/* =========================================================
   IMAGE PREVIEW
========================================================= */
.asset-image-preview {
    margin-top: 0.75rem;
    width: 110px;
    height: 110px;
    border-radius: 12px;
    border: 1px solid rgba(59, 130, 246, 0.2);
    object-fit: cover;
    box-shadow: 0 4px 14px rgba(0,0,0,0.08);
}

/* =========================================================
   ACTION BAR
========================================================= */
.form-actions {
    display: flex;
    gap: 12px;
    align-items: center;
}

/* =========================================================
   BUTTONS
========================================================= */
.btn-primary-glass {
    background: linear-gradient(135deg, #3b82f6, #1e40af);
    color: white;
    border-radius: 10px;
    border: none;
    padding: 10px 26px;
    font-weight: 500;
    transition: var(--transition);
}

.btn-primary-glass:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(59, 130, 246, 0.35);
}

.btn-glass {
    background: rgba(59, 130, 246, 0.1);
    border: 1px solid rgba(59, 130, 246, 0.25);
    border-radius: 10px;
    padding: 10px 22px;
    color: #3b82f6;
    transition: var(--transition);
}

.btn-glass:hover {
    background: rgba(59, 130, 246, 0.2);
    transform: translateY(-2px);
}

/* =========================================================
   RESPONSIVE
========================================================= */
@media (max-width: 768px) {
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
}
</style>

<div class="assets-form-page">

    <!-- PAGE HEADER -->
    <div class="dashboard-header mb-4 d-flex justify-content-between align-items-center">
        <div>
            <h1><?= $title ?></h1>
            <p><?= $isEdit ? 'Modify existing laboratory asset details' : 'Register a new laboratory asset' ?></p>
        </div>

        <a href="/admin/assets" class="btn btn-glass">
            <i class="bi bi-arrow-left me-1"></i> Back
        </a>
    </div>

    <!-- FORM CARD -->
    <div class="glass-card">

        <div class="settings-card-header">
            <h5>
                <i class="bi bi-archive-fill"></i>
                Asset Information
            </h5>
        </div>

        <div class="card-body p-4">

            <form action="<?= $action ?>" method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>

                <div class="row g-4">

                    <!-- Asset Name -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-box"></i>
                                Asset Name
                            </label>
                            <input type="text"
                                   name="name"
                                   required
                                   class="form-control form-control-glass"
                                   placeholder="e.g. Oscilloscope"
                                   value="<?= esc($asset['name'] ?? '') ?>">
                        </div>
                    </div>

                    <!-- Laboratory -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-building"></i>
                                Laboratory
                            </label>
                            <select name="lab_id" class="form-control form-control-glass" required>
                                <option value="">Select Laboratory</option>
                                <?php foreach ($labs as $lab): ?>
                                    <option value="<?= $lab['id'] ?>"
                                        <?= ($asset['lab_id'] ?? '') == $lab['id'] ? 'selected' : '' ?>>
                                        <?= esc($lab['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Quantity -->
                    <div class="col-md-4">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-123"></i>
                                Quantity
                            </label>
                            <input type="number"
                                   name="quantity"
                                   min="1"
                                   required
                                   class="form-control form-control-glass"
                                   value="<?= esc($asset['quantity'] ?? 1) ?>">
                        </div>
                    </div>

                    <!-- Status -->
                    <div class="col-md-4">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-toggle-on"></i>
                                Status
                            </label>
                            <select name="status" class="form-control form-control-glass" required>
                                <option value="available" <?= ($asset['status'] ?? '') === 'available' ? 'selected' : '' ?>>Available</option>
                                <option value="maintenance" <?= ($asset['status'] ?? '') === 'maintenance' ? 'selected' : '' ?>>Maintenance</option>
                                <option value="faulty" <?= ($asset['status'] ?? '') === 'faulty' ? 'selected' : '' ?>>Faulty</option>
                            </select>
                        </div>
                    </div>

                    <!-- Image -->
                    <div class="col-md-4">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-image"></i>
                                Asset Image
                            </label>
                            <input type="file" name="image" class="form-control form-control-glass">

                            <?php if ($isEdit && !empty($asset['image'])): ?>
                                <img src="<?= esc($asset['image']) ?>" class="asset-image-preview">
                            <?php endif; ?>
                        </div>
                    </div>

                </div>

                <!-- ACTIONS -->
                <div class="border-top pt-4 mt-4 form-actions">
                    <button type="submit" class="btn btn-primary-glass">
                        <i class="bi bi-save me-2"></i>
                        <?= $isEdit ? 'Update Asset' : 'Create Asset' ?>
                    </button>

                    <a href="/admin/assets" class="btn btn-glass">
                        Cancel
                    </a>
                </div>

            </form>

        </div>
    </div>
</div>

<?= $this->endSection() ?>
