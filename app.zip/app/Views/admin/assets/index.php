<?= $this->extend('layouts/main_admin') ?>
<?= $this->section('content') ?>

<style>
    .assets-page {
        --card-radius: 16px;
        --transition-speed: 0.3s;
    }

    .glass-card {
        background: linear-gradient(135deg, rgba(255,255,255,0.95), rgba(255,255,255,0.98));
        backdrop-filter: blur(12px);
        border-radius: 16px;
        border: 1px solid rgba(59,130,246,0.15);
        box-shadow: 0 8px 32px rgba(0,0,0,0.08);
        overflow: hidden;
    }

    .dashboard-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: #1e293b;
    }

    .dashboard-header p {
        color: #64748b;
        font-size: 0.95rem;
    }

    .settings-card-header {
        background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(30,64,175,0.05));
        border-bottom: 1px solid rgba(59,130,246,0.1);
        padding: 1.25rem 1.5rem;
    }

    .settings-card-header h5 {
        margin: 0;
        font-weight: 600;
        color: #1e293b;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .btn-primary-glass {
        background: linear-gradient(135deg, #3b82f6, #1e40af);
        color: white;
        border-radius: 10px;
        border: none;
        padding: 10px 22px;
        transition: 0.3s;
    }

    .btn-primary-glass:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(59,130,246,0.3);
    }

    .table-glass {
        background: rgba(255,255,255,0.9);
        border-radius: 12px;
        border: 1px solid rgba(59,130,246,0.1);
        overflow: hidden;
    }

    .table-glass thead {
        background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(30,64,175,0.05));
    }

    .table-glass th {
        font-weight: 600;
        color: #1e293b;
        padding: 1rem;
    }

    .table-glass td {
        padding: 1rem;
        border-color: rgba(59,130,246,0.1);
    }

    .table-glass tbody tr:hover {
        background: rgba(59,130,246,0.03);
    }

    .alert-glass {
        background: linear-gradient(135deg, rgba(240,253,244,0.95), rgba(220,252,231,0.98));
        border: 1px solid rgba(34,197,94,0.2);
        border-radius: 12px;
    }
</style>

<div class="assets-page">

    <!-- HEADER -->
    <div class="dashboard-header mb-4 d-flex justify-content-between align-items-center">
        <div>
            <h1>Assets</h1>
            <p>Manage laboratory equipment and availability</p>
        </div>
        <a href="/admin/assets/create" class="btn btn-primary-glass">
            <i class="bi bi-plus-circle me-2"></i>Add Asset
        </a>
    </div>

    <!-- FLASH -->
    <?php if (session()->getFlashdata('message')): ?>
        <div class="alert alert-glass mb-4">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?= session()->getFlashdata('message') ?>
        </div>
    <?php endif; ?>

    <!-- TABLE CARD -->
    <div class="glass-card">
        <div class="settings-card-header">
            <h5><i class="bi bi-boxes"></i> Registered Assets</h5>
        </div>

        <div class="p-4">
            <?php if (empty($assets)): ?>
                <div class="text-center text-muted py-5">
                    <i class="bi bi-box fs-1 mb-2"></i>
                    <p>No assets have been added yet</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-glass align-middle">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Asset</th>
                                <th>Lab</th>
                                <th>Qty</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($assets as $a): ?>
                            <tr>
                                <td>
                                    <img src="<?= esc($a['image'] ?? '/images/assets/default.png') ?>"
                                         width="60" height="60"
                                         class="rounded shadow-sm">
                                </td>
                                <td class="fw-semibold"><?= esc($a['name']) ?></td>
                                <td><?= esc($a['lab_name'] ?? '-') ?></td>
                                <td><?= esc($a['quantity']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $a['status'] === 'available' ? 'success' : ($a['status'] === 'maintenance' ? 'warning text-dark' : 'danger') ?>">
                                        <?= ucfirst($a['status']) ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="/admin/assets/edit/<?= $a['id'] ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <button onclick="deleteAsset(<?= $a['id'] ?>)" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function deleteAsset(id) {
    if (!confirm("Delete this asset?")) return;
    fetch(`/admin/assets/delete/${id}`, {
        method: "POST",
        headers: {
            "X-Requested-With": "XMLHttpRequest",
            "X-CSRF-TOKEN": "<?= csrf_hash() ?>"
        }
    }).then(() => location.reload());
}
</script>

<?= $this->endSection() ?>
