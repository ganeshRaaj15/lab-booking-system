<?= $this->extend('layouts/main_admin') ?>
<?= $this->section('content') ?>

<?php
$isEdit = isset($lab);
$title  = $isEdit ? "Edit Laboratory" : "Add Laboratory";
$action = $isEdit ? "/admin/labs/update/" . $lab['id'] : "/admin/labs/store";
?>

<style>
    /* Lab Form – Users Design System */
    .lab-form {
        --card-radius: 16px;
        --transition-speed: 0.3s;
    }

    /* Glass Card */
    .glass-card {
        background: linear-gradient(135deg,
            rgba(255, 255, 255, 0.95),
            rgba(255, 255, 255, 0.98)
        );
        backdrop-filter: blur(12px);
        border-radius: var(--card-radius);
        border: 1px solid rgba(59, 130, 246, 0.15);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
        transition: all var(--transition-speed) ease;
        overflow: hidden;
    }

    .glass-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
    }

    /* Dashboard Header */
    .dashboard-header {
        margin-bottom: 2rem;
    }

    .dashboard-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 0.5rem;
    }

    .dashboard-header p {
        color: #64748b;
        font-size: 0.95rem;
    }

    /* Form Groups */
    .form-group-glass {
        margin-bottom: 1.5rem;
    }

    .form-group-glass label {
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .form-group-glass label i {
        color: #3b82f6;
    }

    .form-control-glass {
        background: rgba(255, 255, 255, 0.95);
        border: 1px solid rgba(59, 130, 246, 0.25);
        border-radius: 10px;
        padding: 0.75rem 1rem;
        transition: all 0.3s ease;
        color: #1e293b;
    }

    .form-control-glass:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.12);
    }

    /* Image preview */
    .image-preview {
        margin-top: 0.75rem;
        border-radius: 12px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
        border: 1px solid rgba(0, 0, 0, 0.08);
    }

    /* Buttons */
    .btn-glass {
        padding: 10px 24px;
        border-radius: 10px;
        border: 1px solid rgba(59, 130, 246, 0.2);
        background: rgba(59, 130, 246, 0.08);
        color: #3b82f6;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .btn-glass:hover {
        background: rgba(59, 130, 246, 0.15);
        border-color: rgba(59, 130, 246, 0.3);
        transform: translateY(-2px);
    }

    /* Info box */
    .info-box {
        background: rgba(241, 245, 249, 0.9);
        border-radius: 12px;
        padding: 1rem 1.25rem;
        border: 1px solid rgba(59, 130, 246, 0.15);
        color: #475569;
        margin-bottom: 1.5rem;
        font-size: 0.95rem;
    }
</style>

<div class="lab-form">

    <!-- PAGE HEADER -->
    <div class="dashboard-header">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h1><?= esc($title) ?></h1>
                <p>Manage laboratory details and PIC information</p>
            </div>

            <a href="/admin/labs" class="btn btn-glass">
                <i class="bi bi-arrow-left me-1"></i> Back to Labs
            </a>
        </div>
    </div>

    <!-- FORM CARD -->
    <div class="glass-card">
        <div class="card-body p-4">

            <div class="info-box">
                <i class="bi bi-info-circle-fill me-2 text-primary"></i>
                Please ensure laboratory and PIC details are accurate for audit and booking workflows.
            </div>

            <form method="post" action="<?= $action ?>" enctype="multipart/form-data">
                <?= csrf_field() ?>

                <div class="row g-4">

                    <!-- Lab Name -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-buildings"></i>
                                Laboratory Name
                            </label>
                            <input type="text"
                                   name="name"
                                   class="form-control form-control-glass"
                                   value="<?= old('name', $lab['name'] ?? '') ?>"
                                   required>
                        </div>
                    </div>

                    <!-- Room -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-door-open"></i>
                                Room
                            </label>
                            <input type="text"
                                   name="room"
                                   class="form-control form-control-glass"
                                   value="<?= old('room', $lab['room'] ?? '') ?>"
                                   required>
                        </div>
                    </div>

                    <!-- PIC Name -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-person"></i>
                                PIC Name
                            </label>
                            <input type="text"
                                   name="pic_name"
                                   class="form-control form-control-glass"
                                   value="<?= old('pic_name', $lab['pic_name'] ?? '') ?>"
                                   required>
                        </div>
                    </div>

                    <!-- PIC Email -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-envelope"></i>
                                PIC Email
                            </label>
                            <input type="email"
                                   name="pic_email"
                                   class="form-control form-control-glass"
                                   value="<?= old('pic_email', $lab['pic_email'] ?? '') ?>"
                                   required>
                        </div>
                    </div>

                    <!-- PIC Phone -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-telephone"></i>
                                PIC Phone
                            </label>
                            <input type="text"
                                   name="pic_phone"
                                   class="form-control form-control-glass"
                                   value="<?= old('pic_phone', $lab['pic_phone'] ?? '') ?>">
                        </div>
                    </div>

                    <!-- Lab Image -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-image"></i>
                                Laboratory Image
                            </label>
                            <input type="file" name="image" class="form-control form-control-glass">
                            <?php if ($isEdit && !empty($lab['image'])): ?>
                                <img src="<?= esc($lab['image']) ?>" width="140" class="image-preview">
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- PIC Image -->
                    <div class="col-md-6">
                        <div class="form-group-glass">
                            <label>
                                <i class="bi bi-person-badge"></i>
                                PIC Profile Image
                            </label>
                            <input type="file" name="pic_image" class="form-control form-control-glass">
                            <?php if ($isEdit && !empty($lab['pic_image'])): ?>
                                <img src="<?= esc($lab['pic_image']) ?>" width="90"
                                     class="image-preview rounded-circle">
                            <?php endif; ?>
                        </div>
                    </div>

                </div>

                <!-- ACTIONS -->
                <div class="border-top pt-4 mt-4">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="bi bi-save me-2"></i>
                        Save Laboratory
                    </button>

                    <a href="/admin/labs" class="btn btn-glass ms-2">
                        Cancel
                    </a>
                </div>

            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
