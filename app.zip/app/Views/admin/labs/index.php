<?= $this->extend('layouts/main_admin') ?>
<?= $this->section('content') ?>

<style>
    /* Lab Management – Users Design System */
    .lab-management {
        --card-radius: 16px;
        --card-padding: 24px;
        --transition-speed: 0.3s;
    }

    /* Glass Card */
    .glass-card {
        background: linear-gradient(135deg,
            rgba(255, 255, 255, 0.95),
            rgba(255, 255, 255, 0.98)
        );
        backdrop-filter: blur(12px);
        border-radius: var(--card-radius);
        border: 1px solid rgba(59, 130, 246, 0.15);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
        transition: all var(--transition-speed) ease;
        overflow: hidden;
    }

    .glass-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
        border-color: rgba(59, 130, 246, 0.25);
    }

    /* Dashboard Header */
    .dashboard-header {
        margin-bottom: 2rem;
    }

    .dashboard-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 0.5rem;
    }

    .dashboard-header p {
        color: #64748b;
        font-size: 0.95rem;
    }

    /* Quick Stats */
    .quick-stat {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        background: rgba(241, 245, 249, 0.8);
        border-radius: 12px;
        border: 1px solid rgba(59, 130, 246, 0.15);
        min-width: 160px;
    }

    .quick-stat i {
        font-size: 1.5rem;
        color: #3b82f6;
        opacity: 0.8;
    }

    /* Glass Table */
    .glass-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        border-radius: 12px;
        overflow: hidden;
        border: 1px solid rgba(59, 130, 246, 0.1);
    }

    .glass-table thead {
        background: linear-gradient(135deg,
            rgba(59, 130, 246, 0.1),
            rgba(30, 64, 175, 0.05)
        );
    }

    .glass-table th {
        border-bottom: 2px solid rgba(59, 130, 246, 0.15);
        padding: 1rem 1.5rem;
        font-weight: 600;
        color: #1e293b;
        white-space: nowrap;
    }

    .glass-table td {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid rgba(59, 130, 246, 0.08);
        vertical-align: middle;
        color: #475569;
    }

    .glass-table tbody tr {
        transition: all 0.2s ease;
    }

    .glass-table tbody tr:hover {
        background: rgba(59, 130, 246, 0.04);
    }

    /* Action Buttons */
    .btn-action {
        width: 36px;
        height: 36px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        transition: all 0.3s ease;
        border: 1px solid rgba(0, 0, 0, 0.1);
    }

    .btn-action.edit {
        background: rgba(59, 130, 246, 0.1);
        color: #3b82f6;
        border-color: rgba(59, 130, 246, 0.2);
    }

    .btn-action.edit:hover {
        background: rgba(59, 130, 246, 0.2);
        transform: translateY(-2px);
    }

    .btn-action.delete {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border-color: rgba(239, 68, 68, 0.2);
    }

    .btn-action.delete:hover {
        background: rgba(239, 68, 68, 0.2);
        transform: translateY(-2px);
    }

    /* Empty State */
    .empty-state {
        padding: 3rem 1rem;
        text-align: center;
        color: #64748b;
    }

    .empty-state i {
        font-size: 3rem;
        margin-bottom: 1rem;
        color: #cbd5e1;
    }
</style>

<div class="lab-management">

    <!-- PAGE HEADER -->
    <div class="dashboard-header">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
            <div>
                <h1>Laboratory Management</h1>
                <p>Manage laboratories, rooms, and PIC assignments</p>
            </div>

            <div class="d-flex gap-3">
                <div class="quick-stat">
                    <i class="bi bi-buildings"></i>
                    <div>
                        <div class="small text-muted">Total Labs</div>
                        <div class="fw-bold"><?= count($labs) ?></div>
                    </div>
                </div>

                <a href="/admin/labs/create" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-1"></i> Add Lab
                </a>
            </div>
        </div>
    </div>

    <!-- FLASH MESSAGES -->
    <?php if (session()->getFlashdata('message')): ?>
        <div class="alert alert-success glass-card mb-4">
            <div class="d-flex align-items-center">
                <i class="bi bi-check-circle-fill fs-5 me-2"></i>
                <div class="flex-grow-1"><?= session()->getFlashdata('message') ?></div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger glass-card mb-4">
            <div class="d-flex align-items-center">
                <i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i>
                <div class="flex-grow-1"><?= session()->getFlashdata('error') ?></div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        </div>
    <?php endif; ?>

    <!-- LAB TABLE -->
    <div class="glass-card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="glass-table">
                    <thead>
                        <tr>
                            <th style="width: 60px;">#</th>
                            <th>Laboratory</th>
                            <th>Room</th>
                            <th>PIC Name</th>
                            <th>PIC Email</th>
                            <th style="width: 100px;" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($labs)): ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="bi bi-buildings"></i>
                                        <h4 class="text-muted mb-2">No Laboratories Found</h4>
                                        <p class="text-muted">Start by adding your first laboratory</p>
                                        <a href="/admin/labs/create" class="btn btn-primary mt-2">
                                            <i class="bi bi-plus-circle me-1"></i> Add Laboratory
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $i = 1; foreach ($labs as $lab): ?>
                                <tr>
                                    <td class="text-muted fw-semibold"><?= $i++ ?></td>

                                    <td class="fw-semibold"><?= esc($lab['name']) ?></td>

                                    <td><?= esc($lab['room']) ?></td>

                                    <td><?= esc($lab['pic_name']) ?></td>

                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <i class="bi bi-envelope text-muted"></i>
                                            <span><?= esc($lab['pic_email']) ?></span>
                                        </div>
                                    </td>

                                    <td class="text-end">
                                        <div class="d-flex justify-content-end gap-2">
                                            <a href="/admin/labs/edit/<?= $lab['id'] ?>"
                                               class="btn-action edit"
                                               title="Edit Laboratory">
                                                <i class="bi bi-pencil"></i>
                                            </a>

                                            <button class="btn-action delete"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal"
                                                    data-id="<?= $lab['id'] ?>"
                                                    title="Delete Laboratory">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->include('admin/labs/delete_modal') ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const deleteModal = document.getElementById("deleteModal");
    deleteModal.addEventListener("show.bs.modal", function (event) {
        const button = event.relatedTarget;
        const id = button.getAttribute("data-id");
        deleteModal.querySelector("form").action = "/admin/labs/delete/" + id;
    });
});
</script>

<?= $this->endSection() ?>
