<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= esc($title ?? 'Dashboard | FKMP Smart Lab') ?></title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Theme -->
    <link href="/css/theme.css" rel="stylesheet">

    <style>
        html, body {
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        :root {
            --admin-navbar-height: 72px;
            --admin-sidebar-width: 260px;
        }

        /* MAIN LAYOUT */
        .admin-layout {
            padding-left: var(--admin-sidebar-width);
            min-height: 100vh;
            background: #f8fafc;
        }

        /* MAIN CONTENT */
        .content-area {
            padding-top: calc(var(--admin-navbar-height) + 20px);
            padding-left: 24px;
            padding-right: 24px;
            padding-bottom: 24px;
            min-height: 100vh;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .admin-layout {
                padding-left: 0;
            }
            .content-area {
                padding-top: calc(var(--admin-navbar-height) + 16px);
            }
        }
    </style>
</head>

<body>

<?= $this->include('components/sidebar_admin') ?>

<div class="admin-layout">
    <?= $this->include('components/navbar_admin') ?>
    
    <div class="content-area">
        <?= $this->renderSection('content') ?>
    </div>
</div>

<?= $this->include('components/footer') ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>