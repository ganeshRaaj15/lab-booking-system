<?php

namespace App\Controllers\Dashboard;

use App\Controllers\BaseController;
use App\Models\BookingModel;
use App\Models\BookingAssetModel;
use App\Models\AssetModel;

class StudentDashboard extends BaseController
{
    public function index()
    {
        helper('auth');

        if (!auth()->loggedIn() || !auth()->user()->inGroup('student')) {
            return redirect()->to('/dashboard')->with('error', 'Access denied.');
        }

        $user   = auth()->user();
        $userId = $user->id;

        $bookingModel = new BookingModel();

        $baseSelect = "
            bookings.*,
            laboratories.name AS lab_name,
            laboratories.room AS lab_room
        ";

        // All bookings
        $bookings = $bookingModel
            ->select($baseSelect)
            ->join('laboratories', 'laboratories.id = bookings.lab_id', 'left')
            ->where('bookings.user_id', $userId)
            ->orderBy('bookings.date', 'DESC')
            ->orderBy('bookings.start_time', 'ASC')
            ->findAll();

        // Stats
        $stats = [
            'pending'  => (new BookingModel())->where('user_id', $userId)->where('status', 'PENDING')->countAllResults(),
            'approved' => (new BookingModel())->where('user_id', $userId)->where('status', 'APPROVED')->countAllResults(),
            'rejected' => (new BookingModel())->where('user_id', $userId)->where('status', 'REJECTED')->countAllResults(),
        ];
        $stats['total'] = $stats['pending'] + $stats['approved'] + $stats['rejected'];

        // Upcoming bookings
        $today = date('Y-m-d');
        $upcomingBookings = $bookingModel
            ->select($baseSelect)
            ->join('laboratories', 'laboratories.id = bookings.lab_id', 'left')
            ->where('bookings.user_id', $userId)
            ->where('bookings.date >=', $today)
            ->orderBy('bookings.date', 'ASC')
            ->orderBy('bookings.start_time', 'ASC')
            ->limit(10)
            ->findAll();

        $nextBooking = $upcomingBookings[0] ?? null;

        // Monthly trend (ONLY_FULL_GROUP_BY safe)
        $db = \Config\Database::connect();
        $monthlyRows = $db->table('bookings')
            ->select("DATE_FORMAT(date, '%b %Y') AS month, COUNT(*) AS count", false)
            ->where('user_id', $userId)
            ->groupBy("DATE_FORMAT(date, '%b %Y')", false)
            ->orderBy("MIN(date)", "DESC", false)
            ->limit(6)
            ->get()
            ->getResultArray();

        $monthlyCounts = array_reverse($monthlyRows);

        return view('dashboard/student/index', [
            'user'             => $user,
            'bookings'         => $bookings,
            'stats'            => $stats,
            'upcomingBookings' => $upcomingBookings,
            'nextBooking'      => $nextBooking,
            'monthlyCounts'    => $monthlyCounts,
        ]);
    }

    // =====================================================
    // BOOKING DETAILS (MODAL AJAX)
    // =====================================================
    public function bookingDetails($id)
    {
        helper('auth');

        $userId = auth()->id();
        $bookingModel = new BookingModel();
        $bookingAssetModel = new BookingAssetModel();

        $booking = $bookingModel
            ->select("
                bookings.*,
                laboratories.name AS lab_name,
                laboratories.room AS lab_room
            ")
            ->join('laboratories', 'laboratories.id = bookings.lab_id', 'left')
            ->where('bookings.id', $id)
            ->where('bookings.user_id', $userId)
            ->first();

        if (!$booking) {
            return $this->response->setJSON(['success' => false, 'message' => 'Booking not found']);
        }

        $assets = $bookingAssetModel
            ->select("booking_assets.*, assets.name")
            ->join("assets", "assets.id = booking_assets.asset_id", "left")
            ->where("booking_id", $id)
            ->findAll();

        return $this->response->setJSON([
            'success' => true,
            'booking' => $booking,
            'assets'  => $assets
        ]);
    }

    // =====================================================
    // CANCEL BOOKING
    // =====================================================
    public function cancelBooking($id)
    {
        helper('auth');

        $userId = auth()->id();
        $bookingModel = new BookingModel();

        $booking = $bookingModel->where('id', $id)->where('user_id', $userId)->first();

        if (!$booking) {
            return $this->response->setJSON(['success' => false, 'message' => 'Booking not found']);
        }

        if ($booking['status'] !== 'PENDING') {
            return $this->response->setJSON(['success' => false, 'message' => 'Only pending bookings can be cancelled.']);
        }

        $bookingModel->update($id, ['status' => 'CANCELLED']);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Booking cancelled successfully.'
        ]);
    }
}
