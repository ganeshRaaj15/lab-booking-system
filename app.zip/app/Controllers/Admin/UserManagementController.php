<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\Shield\Models\UserModel;
use CodeIgniter\Shield\Entities\User;
use CodeIgniter\Database\BaseConnection;

/**
 * User management panel for Admins only.
 */
class UserManagementController extends BaseController
{
    /** @var UserModel */
    protected $users;
    
    /** @var BaseConnection */
    protected $db;

    public function __construct()
    {
        helper('auth');
        $this->users = model(UserModel::class);
        $this->db = db_connect();
    }

    /**
     * List all users + roles
     */
    public function index()
    {
        /** @var User[] $users */
        $users = $this->users->findAll();

        $userData = [];

        foreach ($users as $u) {
            // Get user's email from auth_identities
            $email = '';
            $identity = $this->db->table('auth_identities')
                ->where('user_id', $u->id)
                ->where('type', 'email_password')
                ->get()
                ->getRow();
            
            if ($identity) {
                $email = $identity->secret;
            }
            
            // Get user's roles from auth_groups_users
            $roles = $this->db->table('auth_groups_users')
                ->where('user_id', $u->id)
                ->get()
                ->getResultArray();
            
            $roleNames = array_column($roles, 'group');
            
            $userData[] = [
                'id'       => $u->id,
                'username' => $u->username,
                'email'    => $email,
                'roles'    => $roleNames,
                'active'   => $u->active,
            ];
        }

        return view('admin/users/index', [
            'users' => $userData,
        ]);
    }

    /**
     * Edit a single user's details + roles
     */
    public function edit($id)
    {
        /** @var User|null $user */
        $user = $this->users->findById($id);

        if (! $user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        // Get user's email
        $email = '';
        $identity = $this->db->table('auth_identities')
            ->where('user_id', $user->id)
            ->where('type', 'email_password')
            ->get()
            ->getRow();
        
        if ($identity) {
            $email = $identity->secret;
        }

        // Get user's roles
        $roles = $this->db->table('auth_groups_users')
            ->where('user_id', $user->id)
            ->get()
            ->getResultArray();
        
        $roleNames = array_column($roles, 'group');
        
        // Get all available roles from the database
        $allRoles = $this->db->table('auth_groups_users')
            ->select('group')
            ->distinct()
            ->get()
            ->getResultArray();
        
        $availableRoles = array_column($allRoles, 'group');
        
        // If no roles found, use default roles
        if (empty($availableRoles)) {
            $availableRoles = ['student', 'external', 'pic', 'manager', 'admin'];
        }

        return view('admin/users/edit', [
            'user'  => $user,
            'email' => $email,
            'roles' => $roleNames,
            'allRoles' => $availableRoles,
        ]);
    }

    /**
     * Update user (name, email, roles)
     */
    public function update($id)
    {
        /** @var User|null $user */
        $user = $this->users->findById($id);

        if (! $user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $data = $this->request->getPost();

        // Basic validation
        if (empty($data['email']) || empty($data['username'])) {
            return redirect()->back()->with('error', 'Username and email cannot be empty.');
        }

        // Update user entity
        $user->username = trim($data['username']);
        $this->users->save($user);

        // Update email in auth_identities
        $this->db->table('auth_identities')
            ->where('user_id', $user->id)
            ->where('type', 'email_password')
            ->set('secret', trim($data['email']))
            ->set('updated_at', date('Y-m-d H:i:s'))
            ->update();

        // -----------------------------
        //  Update roles
        // -----------------------------
        $newRoles = $data['roles'] ?? [];

        // Allowed roles in system
        $allowedRoles = ['student', 'external', 'pic', 'manager', 'admin'];

        // Drop any invalid roles
        $newRoles = array_intersect($newRoles, $allowedRoles);

        // Remove all existing roles first
        $this->db->table('auth_groups_users')
            ->where('user_id', $user->id)
            ->delete();

        // Add selected roles back
        $now = date('Y-m-d H:i:s');
        foreach ($newRoles as $role) {
            $this->db->table('auth_groups_users')->insert([
                'user_id' => $user->id,
                'group' => $role,
                'created_at' => $now,
            ]);
        }

        return redirect()
            ->to('/admin/users')
            ->with('message', 'User updated successfully.');
    }

    /**
     * Delete a user completely
     * Safeguards to prevent deleting admins or manager accounts.
     */
    public function delete($id)
    {
        /** @var User|null $user */
        $user = $this->users->findById($id);

        if (! $user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        // Check if user has admin or manager role
        $adminCheck = $this->db->table('auth_groups_users')
            ->where('user_id', $user->id)
            ->whereIn('group', ['admin', 'manager'])
            ->countAllResults() > 0;

        // Prevent critical deletion
        if ($adminCheck) {
            return redirect()->back()->with('error', 'Cannot delete Admin or Manager accounts.');
        }

        // Delete user identities first (foreign key constraint)
        $this->db->table('auth_identities')
            ->where('user_id', $user->id)
            ->delete();
            
        // Delete user roles
        $this->db->table('auth_groups_users')
            ->where('user_id', $user->id)
            ->delete();

        // Delete user
        $this->users->delete($user->id);

        return redirect()
            ->to('/admin/users')
            ->with('message', 'User deleted successfully.');
    }
    
    /**
     * Create new user
     */
    public function create()
    {
        // Get all available roles from the database
        $allRoles = $this->db->table('auth_groups_users')
            ->select('group')
            ->distinct()
            ->get()
            ->getResultArray();
        
        $availableRoles = array_column($allRoles, 'group');
        
        // If no roles found, use default roles
        if (empty($availableRoles)) {
            $availableRoles = ['student', 'external', 'pic', 'manager', 'admin'];
        }

        return view('admin/users/create', [
            'allRoles' => $availableRoles,
        ]);
    }
    
    /**
     * Store new user
     */
    public function store()
    {
        $data = $this->request->getPost();
        
        // Validation
        if (empty($data['email']) || empty($data['username']) || empty($data['password'])) {
            return redirect()->back()->with('error', 'Username, email and password are required.');
        }
        
        if ($data['password'] !== $data['password_confirm']) {
            return redirect()->back()->with('error', 'Passwords do not match.');
        }
        
        // Check if user already exists
        $existing = $this->users->where('username', trim($data['username']))->first();
        if ($existing) {
            return redirect()->back()->with('error', 'Username already exists.');
        }
        
        // Check if email already exists
        $emailExists = $this->db->table('auth_identities')
            ->where('secret', trim($data['email']))
            ->where('type', 'email_password')
            ->countAllResults() > 0;
        
        if ($emailExists) {
            return redirect()->back()->with('error', 'Email already exists.');
        }
        
        // Create user
        $user = new User([
            'username' => trim($data['username']),
            'active' => true,
        ]);
        
        $this->users->save($user);
        
        // Add email identity
        $this->db->table('auth_identities')->insert([
            'user_id' => $user->id,
            'type' => 'email_password',
            'secret' => trim($data['email']),
            'secret2' => password_hash(trim($data['password']), PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        
        // Add roles
        $newRoles = $data['roles'] ?? [];
        $allowedRoles = ['student', 'external', 'pic', 'manager', 'admin'];
        $newRoles = array_intersect($newRoles, $allowedRoles);
        
        $now = date('Y-m-d H:i:s');
        foreach ($newRoles as $role) {
            $this->db->table('auth_groups_users')->insert([
                'user_id' => $user->id,
                'group' => $role,
                'created_at' => $now,
            ]);
        }
        
        return redirect()
            ->to('/admin/users')
            ->with('message', 'User created successfully.');
    }
}