<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\LaboratoryModel;

class LaboratoryAdminController extends BaseController
{
    protected $labModel;

    public function __construct()
    {
        helper(['auth', 'filesystem']);

        // RBAC check (Admin only)
        if (! auth()->loggedIn() || ! auth()->user()->inGroup('admin')) {
            redirect()->to('/')->with('error', 'You are not authorized to access this page.')->send();
            exit;
        }

        $this->labModel = new LaboratoryModel();
    }

    /**
     * List all laboratories (Admin UI)
     */
    public function index()
    {
        $labs = $this->labModel->orderBy('name', 'ASC')->findAll();

        return view('admin/labs/index', [
            'labs' => $labs
        ]);
    }

    /**
     * Show the create lab form
     */
    public function create()
{
    return view('admin/labs/form');
}


    /**
     * Store a new laboratory
     */
    public function store()
    {
        $rules = [
            'name'      => 'required|string',
            'room'      => 'permit_empty|string',
            'pic_name'  => 'required|string',
            'pic_email' => 'permit_empty|valid_email',
            'pic_phone' => 'permit_empty|string',
            'image'     => 'permit_empty|uploaded[image]|max_size[image,2048]|is_image[image]',
            'pic_image' => 'permit_empty|uploaded[pic_image]|max_size[pic_image,2048]|is_image[pic_image]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        // Upload lab image
        $labImage = null;
        if ($file = $this->request->getFile('image')) {
            if ($file->isValid()) {
                $newName = $file->getRandomName();
                $file->move(FCPATH . 'uploads/labs', $newName);
                $labImage = 'uploads/labs/' . $newName;
            }
        }

        // Upload PIC image
        $picImage = null;
        if ($pic = $this->request->getFile('pic_image')) {
            if ($pic->isValid()) {
                $newName = $pic->getRandomName();
                $pic->move(FCPATH . 'uploads/pic', $newName);
                $picImage = 'uploads/pic/' . $newName;
            }
        }

        // Insert lab
        $this->labModel->insert([
            'name'       => $this->request->getPost('name'),
            'room'       => $this->request->getPost('room'),
            'pic_name'   => $this->request->getPost('pic_name'),
            'pic_email'  => $this->request->getPost('pic_email'),
            'pic_phone'  => $this->request->getPost('pic_phone'),
            'image'      => $labImage,
            'pic_image'  => $picImage
        ]);

        return redirect()->to('/admin/labs')->with('message', 'Laboratory created successfully.');
    }

    /**
     * Edit laboratory info
     */
   public function edit($id)
{
    $lab = $this->labModel->find($id);

    if (! $lab) {
        return redirect()->to('/admin/labs')->with('error', 'Laboratory not found.');
    }

    return view('admin/labs/form', [
        'lab' => $lab
    ]);
}

    /**
     * Update laboratory
     */
    public function update($id)
    {
        $lab = $this->labModel->find($id);

        if (! $lab) {
            return redirect()->to('/admin/labs')->with('error', 'Laboratory not found.');
        }

        $rules = [
            'name'      => 'required|string',
            'room'      => 'permit_empty|string',
            'pic_name'  => 'required|string',
            'pic_email' => 'permit_empty|valid_email',
            'pic_phone' => 'permit_empty|string',
            'image'     => 'permit_empty|uploaded[image]|max_size[image,2048]|is_image[image]',
            'pic_image' => 'permit_empty|uploaded[pic_image]|max_size[pic_image,2048]|is_image[pic_image]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        // Handle image replacement (lab image)
        $labImage = $lab['image'];
        if ($file = $this->request->getFile('image')) {
            if ($file->isValid()) {
                // delete old
                if ($labImage && file_exists(FCPATH . $labImage)) {
                    unlink(FCPATH . $labImage);
                }
                // upload new
                $newName = $file->getRandomName();
                $file->move(FCPATH . 'uploads/labs', $newName);
                $labImage = 'uploads/labs/' . $newName;
            }
        }

        // Handle PIC image replacement
        $picImage = $lab['pic_image'];
        if ($pic = $this->request->getFile('pic_image')) {
            if ($pic->isValid()) {
                if ($picImage && file_exists(FCPATH . $picImage)) {
                    unlink(FCPATH . $picImage);
                }
                $newName = $pic->getRandomName();
                $pic->move(FCPATH . 'uploads/pic', $newName);
                $picImage = 'uploads/pic/' . $newName;
            }
        }

        // Update lab
        $this->labModel->update($id, [
            'name'       => $this->request->getPost('name'),
            'room'       => $this->request->getPost('room'),
            'pic_name'   => $this->request->getPost('pic_name'),
            'pic_email'  => $this->request->getPost('pic_email'),
            'pic_phone'  => $this->request->getPost('pic_phone'),
            'image'      => $labImage,
            'pic_image'  => $picImage
        ]);

        return redirect()->to('/admin/labs')->with('message', 'Laboratory updated successfully.');
    }

    /**
     * Delete a laboratory
     */
    public function delete($id)
    {
        $lab = $this->labModel->find($id);

        if (! $lab) {
            return redirect()->to('/admin/labs')->with('error', 'Laboratory not found.');
        }

        // Delete images if exist
        if ($lab['image'] && file_exists(FCPATH . $lab['image'])) {
            unlink(FCPATH . $lab['image']);
        }

        if ($lab['pic_image'] && file_exists(FCPATH . $lab['pic_image'])) {
            unlink(FCPATH . $lab['pic_image']);
        }

        $this->labModel->delete($id);

        return redirect()->to('/admin/labs')->with('message', 'Laboratory deleted successfully.');
    }
}
