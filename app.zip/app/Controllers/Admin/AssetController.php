<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\AssetModel;
use App\Models\LaboratoryModel;

class AssetController extends BaseController
{
    protected $assetModel;
    protected $labModel;

    public function __construct()
    {
        helper('auth');

        if (!auth()->loggedIn() || !auth()->user()->inGroup('admin')) {
            redirect()->to('/')->send();
            exit;
        }

        $this->assetModel = new AssetModel();
        $this->labModel   = new LaboratoryModel();
    }

    public function index()
    {
        $assets = $this->assetModel
            ->select('assets.*, laboratories.name AS lab_name')
            ->join('laboratories', 'laboratories.id = assets.lab_id', 'left')
            ->orderBy('lab_id', 'ASC')
            ->orderBy('name', 'ASC')
            ->findAll();

        return view('admin/assets/index', ['assets' => $assets]);
    }

    public function create()
    {
        return view('admin/assets/form', [
            'mode' => 'create',
            'labs' => $this->labModel->findAll()
        ]);
    }

    public function store()
    {
        $this->assetModel->insert([
            'name'     => $this->request->getPost('name'),
            'lab_id'   => $this->request->getPost('lab_id'),
            'quantity' => $this->request->getPost('quantity'),
            'status'   => $this->request->getPost('status')
        ]);

        return redirect()->to('/admin/assets')->with('message', 'Asset created.');
    }

    public function edit($id)
    {
        return view('admin/assets/form', [
            'mode'  => 'edit',
            'asset' => $this->assetModel->find($id),
            'labs'  => $this->labModel->findAll()
        ]);
    }

    public function update($id)
    {
        $this->assetModel->update($id, [
            'name'     => $this->request->getPost('name'),
            'lab_id'   => $this->request->getPost('lab_id'),
            'quantity' => $this->request->getPost('quantity'),
            'status'   => $this->request->getPost('status')
        ]);

        return redirect()->to('/admin/assets')->with('message', 'Asset updated.');
    }

    public function delete($id)
    {
        $this->assetModel->delete($id);

        if ($this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'success']);
        }

        return redirect()->to('/admin/assets');
    }
}
