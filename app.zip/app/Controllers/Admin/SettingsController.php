<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SettingsModel;

class SettingsController extends BaseController
{
    protected $settings;

    public function __construct()
    {
        helper(['auth']);

        if (!auth()->loggedIn() || !auth()->user()->inGroup('admin')) {
            redirect()->to('/')->with('error', 'Unauthorized access.')->send();
            exit;
        }

        $this->settings = new SettingsModel();
    }

    /**
     * Display all settings including booking slot editor
     */
    public function index()
    {
        // Fetch normal settings
        $rows = $this->settings
            ->where('class', 'system')
            ->orderBy('key', 'ASC')
            ->findAll();

        $settings = [];
        foreach ($rows as $row) {
            $settings[$row['key']] = [
                'value' => $row['value'],
                'type'  => $row['type']
            ];
        }

        // Load booking slots JSON
        $slotsJson = setting('system.booking_slots') ?? '[]';
        $bookingSlots = json_decode($slotsJson, true);

        return view('admin/settings/index', [
            'settings'      => $settings,
            'bookingSlots'  => $bookingSlots
        ]);
    }


    /**
     * Save non-slot settings (emails, faculty, etc.)
     */
    public function update()
    {
        $rules = [
            'lab_manager_email'   => 'required|valid_email',
            'deputy_dean_email'   => 'required|valid_email',
            'lab_assistant_email' => 'required|valid_email',
            'fkmp_faculty_id'     => 'required|integer'
        ];

        if (!$this->validate($rules)) {
            return redirect()
                ->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $keys = [
            'lab_manager_email',
            'deputy_dean_email',
            'lab_assistant_email',
            'fkmp_faculty_id'
        ];

        foreach ($keys as $key) {
            $this->settings
                ->where('class', 'system')
                ->where('key', $key)
                ->set([
                    'value'      => $this->request->getPost($key),
                    'updated_at' => date('Y-m-d H:i:s')
                ])
                ->update();
        }

        return redirect()->to('/admin/settings')->with('message', 'Settings updated.');
    }


    /**
     * AJAX: Save booking slots
     */
    public function saveSlots()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Invalid request type.'
            ]);
        }

        $slots = $this->request->getPost('slots');

        if (!is_array($slots)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Invalid slots format.'
            ]);
        }

        // Validate each time slot
        foreach ($slots as $slot) {
            if (
                empty($slot['start']) ||
                empty($slot['end'])
            ) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Each slot must have start and end times.'
                ]);
            }

            if ($slot['start'] >= $slot['end']) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Start time must be earlier than end time.'
                ]);
            }
        }

        // Generate labels automatically
        foreach ($slots as &$s) {
            $s['label'] = $s['start'] . ' – ' . $s['end'];
        }

        // Convert to JSON
        $json = json_encode($slots);

        // Save to settings table
        $this->settings
            ->where('class', 'system')
            ->where('key', 'booking_slots')
            ->set([
                'value'      => $json,
                'updated_at' => date('Y-m-d H:i:s')
            ])
            ->update();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Booking slots updated successfully.',
            'slots'   => $slots
        ]);
    }
}
