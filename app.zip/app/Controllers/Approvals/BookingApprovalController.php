<?php

namespace App\Controllers\Approvals;

use App\Controllers\BaseController;
use App\Models\BookingModel;
use App\Models\BookingApplicantModel;
use App\Models\LaboratoryModel;
use Config\Database;

class BookingApprovalController extends BaseController
{
    /**
     * APPROVE BOOKING - CORRECTED VERSION
     * 
     * Rules:
     * 1. PIC can approve ANY booking for their lab (both FKMP and Non-FKMP)
     * 2. For FKMP bookings: PIC approval = FINAL approval
     * 3. For Non-FKMP bookings: PIC approval needed first, then Manager approval
     */
    public function approve($id)
    {
        helper('auth');

        if (!auth()->loggedIn()) {
            return $this->respondForbidden('You must be logged in to approve bookings.');
        }

        $bookingModel = new BookingModel();
        $labModel = new LaboratoryModel();

        $booking = $bookingModel->find($id);

        if (!$booking) {
            return $this->respondNotFound('Booking not found.');
        }

        $user = auth()->user();
        $userEmail = $user->email;

        $isPic = $user->inGroup('pic');
        $isManager = $user->inGroup('manager') || $user->inGroup('admin');

        if (!$isPic && !$isManager) {
            return $this->respondForbidden('You are not authorized to approve this booking.');
        }

        // Determine if this is an FKMP booking
        $isFkmpBooking = ($booking['approval_flow'] === 'FKMP_APPROVAL');

        // Load lab for ownership checks
        $lab = $labModel->find($booking['lab_id']);

        if (!$lab) {
            return $this->respondNotFound('Associated laboratory not found.');
        }

        // ============================================
        // PIC APPROVAL (For ANY booking in their lab)
        // ============================================
        if ($isPic) {
            // PIC can only act on labs they are PIC for
            if (empty($lab['pic_email']) || trim($lab['pic_email']) !== trim($userEmail)) {
                return $this->respondForbidden('You are not the PIC for this laboratory.');
            }

            if ($booking['status'] === 'REJECTED') {
                return $this->respondForbidden('Cannot approve a rejected booking.');
            }

            if ($booking['status'] === 'APPROVED') {
                return $this->successResponse('This booking is already approved.', 'APPROVED');
            }

            // First-time PIC approval
            if (!(int)$booking['approved_by_pic']) {
                $updates = [
                    'approved_by_pic' => 1,
                    'updated_at' => date('Y-m-d H:i:s')
                ];

                if ($isFkmpBooking) {
                    // FKMP: PIC is the final approver
                    $updates['approved_by_manager'] = 1;     // auto-marked as manager approved
                    $updates['status'] = 'APPROVED';
                    
                    $bookingModel->update($id, $updates);
                    
                    // Send final approval notification
                    $this->sendApprovalBlast($booking);
                    
                    return $this->successResponse(
                        'Booking approved successfully (Final approval for FKMP).',
                        'APPROVED'
                    );
                } else {
                    // Non-FKMP: PIC approves, but needs manager approval
                    $updates['status'] = 'PENDING'; // Still pending manager approval
                    
                    $bookingModel->update($id, $updates);
                    
                    // Send notification that PIC approved, awaiting manager
                    $this->sendPICApprovalNotification($booking);
                    
                    return $this->successResponse(
                        'PIC approved. Booking now awaits Manager approval.',
                        'PENDING_MANAGER'
                    );
                }
            }

            // PIC had already approved earlier
            return $this->successResponse(
                'PIC has already approved this booking.',
                $isFkmpBooking ? 'APPROVED' : 'PENDING_MANAGER'
            );
        }

        // ============================================
        // MANAGER / ADMIN APPROVAL (Non-FKMP only)
        // ============================================
        if ($isManager) {
            // Manager can only approve Non-FKMP bookings
            if ($isFkmpBooking) {
                return $this->respondForbidden('Manager approval is not required for FKMP bookings.');
            }

            // Check if PIC has approved first
            if (!(int)$booking['approved_by_pic']) {
                return $this->respondForbidden('PIC must approve before the Manager can approve.');
            }

            if ($booking['status'] === 'REJECTED') {
                return $this->respondForbidden('Cannot approve a rejected booking.');
            }

            if ((int)$booking['approved_by_manager'] && $booking['status'] === 'APPROVED') {
                return $this->successResponse('Booking already approved.', 'APPROVED');
            }

            // Manager approves (final approval for Non-FKMP)
            $bookingModel->update($id, [
                'approved_by_manager' => 1,
                'status' => 'APPROVED',
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            $updated = $bookingModel->find($id);

            // Send final approval notification
            $this->sendApprovalBlast($updated);

            return $this->successResponse('Booking fully approved by Manager.', 'APPROVED');
        }

        return $this->respondForbidden('You are not authorized to approve this booking.');
    }

    /**
     * REJECT BOOKING - CORRECTED VERSION
     * 
     * Rules:
     * 1. PIC can reject ANY booking for their lab
     * 2. Manager can reject Non-FKMP bookings (but not FKMP ones)
     */
    public function reject($id)
    {
        helper('auth');

        if (!auth()->loggedIn()) {
            return $this->respondForbidden('You must be logged in to reject bookings.');
        }

        $bookingModel = new BookingModel();
        $labModel = new LaboratoryModel();

        $booking = $bookingModel->find($id);

        if (!$booking) {
            return $this->respondNotFound('Booking not found.');
        }

        $user = auth()->user();
        $userEmail = $user->email;

        $isPic = $user->inGroup('pic');
        $isManager = $user->inGroup('manager') || $user->inGroup('admin');

        if (!$isPic && !$isManager) {
            return $this->respondForbidden('You are not authorized to reject this booking.');
        }

        if ($booking['status'] === 'REJECTED') {
            return $this->successResponse('Booking already rejected.', 'REJECTED');
        }

        // Determine if this is an FKMP booking
        $isFkmpBooking = ($booking['approval_flow'] === 'FKMP_APPROVAL');
        $lab = $labModel->find($booking['lab_id']);

        // ============================================
        // PIC REJECTION (Can reject ANY booking)
        // ============================================
        if ($isPic) {
            // Check if PIC is authorized for this lab
            if (empty($lab['pic_email']) || trim($lab['pic_email']) !== trim($userEmail)) {
                return $this->respondForbidden('You are not the PIC for this laboratory.');
            }

            // PIC can reject any booking for their lab
            $updates = [
                'status' => 'REJECTED',
                'approved_by_pic' => 0,
                'approved_by_manager' => 0, // Reset manager approval too
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $bookingModel->update($id, $updates);
            $updated = $bookingModel->find($id);

            // Send rejection email
            $this->sendStudentStatusEmail($updated, 'REJECTED', 'PIC');

            return $this->successResponse('Booking rejected by PIC.', 'REJECTED');
        }

        // ============================================
        // MANAGER/ADMIN REJECTION (Non-FKMP only)
        // ============================================
        if ($isManager) {
            // Manager can only reject Non-FKMP bookings
            if ($isFkmpBooking) {
                return $this->respondForbidden('Manager cannot reject FKMP bookings - only PIC can handle them.');
            }

            // Manager can reject even if PIC hasn't approved yet
            $updates = [
                'status' => 'REJECTED',
                'approved_by_manager' => 0,
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $bookingModel->update($id, $updates);
            $updated = $bookingModel->find($id);

            // Send rejection email
            $this->sendStudentStatusEmail($updated, 'REJECTED', 'Manager');

            return $this->successResponse('Booking rejected by Manager.', 'REJECTED');
        }

        return $this->respondForbidden('You are not authorized to reject this booking.');
    }

    // ============================================================
    // RESPONSE HELPERS
    // ============================================================

    protected function respondNotFound(string $msg)
    {
        if ($this->request->isAJAX()) {
            return $this->response->setStatusCode(404)
                ->setJSON(['status' => 'error', 'message' => $msg]);
        }

        return redirect()->back()->with('error', $msg);
    }

    protected function respondForbidden(string $msg)
    {
        if ($this->request->isAJAX()) {
            return $this->response->setStatusCode(403)
                ->setJSON(['status' => 'error', 'message' => $msg]);
        }

        return redirect()->back()->with('error', $msg);
    }

    protected function successResponse(string $msg, string $status)
    {
        if ($this->request->isAJAX()) {
            return $this->response->setJSON([
                'status' => 'success',
                'newStatus' => $status,
                'message' => $msg,
            ]);
        }

        return redirect()->back()->with('message', $msg);
    }

    // ============================================================
    // EMAIL HELPERS
    // ============================================================

    /**
     * Send notification when PIC approves (for Non-FKMP, awaiting manager)
     */
    protected function sendPICApprovalNotification(array $booking): void
    {
        try {
            $studentEmail = $this->getApplicantEmail($booking);
            if (!$studentEmail) {
                return;
            }

            $email = service('email');
            $email->setTo($studentEmail);
            $email->setSubject('FKMP Smart Lab: PIC Approved - Awaiting Manager');

            $msg = "Your booking has been approved by the Person In Charge (PIC).\n\n"
                 . "It is now awaiting final approval from the Lab Manager.\n\n"
                 . "Booking Details:\n"
                 . "Date: {$booking['date']}\n"
                 . "Time: {$booking['start_time']} - {$booking['end_time']}\n"
                 . "Activity: {$booking['activity']}\n\n"
                 . "You will receive another notification when the Manager reviews it.";

            $email->setMessage(nl2br($msg));
            $email->send();
        } catch (\Throwable $e) {
            log_message('error', 'PIC approval notification error: ' . $e->getMessage());
        }
    }

    protected function sendStudentStatusEmail(array $booking, string $newStatus, string $rejectedBy = ''): void
    {
        try {
            $studentEmail = $this->getApplicantEmail($booking);
            if (!$studentEmail) {
                return;
            }

            $email = service('email');

            $email->setTo($studentEmail);
            $subject = "FKMP Smart Lab Booking: {$newStatus}";
            if ($rejectedBy) {
                $subject .= " by {$rejectedBy}";
            }
            $email->setSubject($subject);

            $msg = "Your booking has been updated to status: {$newStatus}.\n\n"
                . "Date: {$booking['date']}\n"
                . "Time: {$booking['start_time']} - {$booking['end_time']}\n"
                . "Activity: {$booking['activity']}\n\n";

            if ($rejectedBy) {
                $msg .= "Rejected by: {$rejectedBy}\n";
            }

            $email->setMessage(nl2br($msg));
            $email->send();
        } catch (\Throwable $e) {
            log_message('error', 'Student status email error: ' . $e->getMessage());
        }
    }

    protected function sendApprovalBlast(array $booking): void
    {
        try {
            $email = service('email');

            // Settings keys use dot syntax
            $manager = setting('system.lab_manager_email');
            $deputy = setting('system.deputy_dean_email');
            $assistant = setting('system.lab_assistant_email');
            $student = $this->getApplicantEmail($booking);

            if (!$manager) {
                // If manager email not configured, still try to notify student
                if ($student) {
                    $email->setTo($student);
                } else {
                    return;
                }
            } else {
                $email->setTo($manager);
                $email->setCC(array_filter([$deputy, $assistant, $student]));
            }

            $email->setSubject('Booking Approval Completed – FKMP Smart Lab');

            $msg = "A booking has been approved.\n\n"
                . "Date: {$booking['date']}\n"
                . "Time: {$booking['start_time']} - {$booking['end_time']}\n"
                . "Activity: {$booking['activity']}";

            $email->setMessage(nl2br($msg));
            $email->send();
        } catch (\Throwable $e) {
            log_message('error', 'Approval blast error: ' . $e->getMessage());
        }
    }

    protected function getApplicantEmail(array $booking): ?string
    {
        $db = Database::connect();

        // If tied to Shield user account
        if (!empty($booking['user_id'])) {
            $row = $db->table('auth_identities')
                ->select('secret')
                ->where('user_id', $booking['user_id'])
                ->where('type', 'email_password')
                ->get()
                ->getRowArray();

            if ($row && !empty($row['secret'])) {
                return $row['secret'];
            }
        }

        // Fallback to applicant record
        $appModel = new BookingApplicantModel();

        $app = $appModel->where('booking_id', $booking['id'])
            ->orderBy('id', 'ASC')
            ->first();

        return $app['email'] ?? null;
    }
}