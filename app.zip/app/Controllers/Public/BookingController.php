<?php

namespace App\Controllers\Public;

use App\Controllers\BaseController;
use App\Models\BookingModel;
use App\Models\BookingAssetModel;
use App\Models\AssetModel;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;

class BookingController extends BaseController
{
    /*
    |--------------------------------------------------------------------------
    | SLOT DEFINITIONS  (Will later be moved to settings table)
    |--------------------------------------------------------------------------
    */
    protected function getSlotDefinitions(): array
    {
        return [
            ['label' => '08:00 – 10:00', 'start' => '08:00:00', 'end' => '10:00:00'],
            ['label' => '10:00 – 12:00', 'start' => '10:00:00', 'end' => '12:00:00'],
            ['label' => '13:00 – 15:00', 'start' => '13:00:00', 'end' => '15:00:00'],
            ['label' => '15:00 – 17:00', 'start' => '15:00:00', 'end' => '17:00:00'],
        ];
    }

    protected function normalizeTime(string $time): string
    {
        $time = trim($time);

        if ($time === '') return $time;
        if (preg_match('/^\d{2}:\d{2}:\d{2}$/', $time)) return $time;
        if (preg_match('/^\d{2}:\d{2}$/', $time)) return $time . ':00';

        return $time;
    }

    /*
    |--------------------------------------------------------------------------
    | ASSET STRING PARSER "1:2,5:1" => [1=>2,5=>1]
    |--------------------------------------------------------------------------
    */
    protected function parseAssetsString(?string $raw): array
    {
        $result = [];
        if (empty($raw)) return $result;

        foreach (explode(',', $raw) as $pair) {
            [$id, $qty] = array_pad(explode(':', trim($pair)), 2, null);
            $id  = (int) $id;
            $qty = (int) $qty;
            if ($id > 0 && $qty > 0) {
                $result[$id] = $qty;
            }
        }
        return $result;
    }

    /*
    |--------------------------------------------------------------------------
    | ASSET AVAILABILITY ENGINE
    |--------------------------------------------------------------------------
    */
    protected function computeRemainingForSlot(
        int $labId,
        string $date,
        string $start,
        string $end,
        array $selectedAssets
    ): array {

        if (empty($selectedAssets)) return [];

        $assetModel = new AssetModel();

        // Base quantities
        $assets = $assetModel->where('lab_id', $labId)
                             ->whereIn('id', array_keys($selectedAssets))
                             ->findAll();

        $base = [];
        foreach ($assets as $asset) {
            $base[(int)$asset['id']] = (int)$asset['quantity'];
        }

        // Ensure all selected assets have base quantity
        foreach ($selectedAssets as $id => $val) {
            if (!isset($base[$id])) $base[$id] = 0;
        }

        $db = \Config\Database::connect();

        $start = $this->normalizeTime($start);
        $end   = $this->normalizeTime($end);

        // Get used quantities for overlapping bookings
        $rows = $db->table('booking_assets ba')
            ->select('ba.asset_id, SUM(ba.quantity_used) AS used_qty')
            ->join('bookings b', 'b.id = ba.booking_id')
            ->where('b.lab_id', $labId)
            ->where('b.date', $date)
            ->whereIn('b.status', ['PENDING', 'APPROVED'])
            ->where('b.start_time <', $end)   // overlap rules
            ->where('b.end_time >', $start)
            ->whereIn('ba.asset_id', array_keys($selectedAssets))
            ->groupBy('ba.asset_id')
            ->get()->getResultArray();

        $used = [];
        foreach ($rows as $r) {
            $used[(int)$r['asset_id']] = (int)$r['used_qty'];
        }

        // Compute remaining
        $remaining = [];
        foreach ($selectedAssets as $assetId => $need) {
            $remaining[$assetId] = max(($base[$assetId] ?? 0) - ($used[$assetId] ?? 0), 0);
        }

        return $remaining;
    }

    /*
    |--------------------------------------------------------------------------
    | MONTH VIEW – FULLCALENDAR (ASSET-AWARE)
    |--------------------------------------------------------------------------
    */
    public function calendarWithAssets(int $labId): ResponseInterface
    {
        $selected = $this->parseAssetsString($this->request->getGet('assets'));

        return $this->response->setJSON([
            'unavailableDates' => $this->calendarAssetsInternal($labId, $selected)
        ]);
    }

    protected function calendarAssetsInternal(int $labId, array $selected): array
    {
        if (empty($selected)) return [];

        $db = \Config\Database::connect();
        $today = date('Y-m-d');
        $slotDefs = $this->getSlotDefinitions();

        $dates = $db->table('bookings')
            ->select('DISTINCT date')
            ->where('lab_id', $labId)
            ->where('date >=', $today)
            ->whereIn('status', ['PENDING', 'APPROVED'])
            ->get()->getResultArray();

        $dates = array_column($dates, 'date');
        $unavailable = [];

        foreach ($dates as $date) {

            $hasValidSlot = false;

            foreach ($slotDefs as $slot) {

                $remaining = $this->computeRemainingForSlot(
                    $labId, $date, $slot['start'], $slot['end'], $selected
                );

                $slotOK = true;

                foreach ($selected as $id => $need) {
                    if (($remaining[$id] ?? 0) < $need) {
                        $slotOK = false;
                        break;
                    }
                }

                if ($slotOK) {
                    $hasValidSlot = true;
                    break;
                }
            }

            if (! $hasValidSlot) {
                $unavailable[] = $date;
            }
        }

        return $unavailable;
    }

    /*
    |--------------------------------------------------------------------------
    | DAY VIEW – TIMESLOT DETAIL (ASSET-AWARE)
    |--------------------------------------------------------------------------
    */
    public function dayWithAssets(int $labId, string $date): ResponseInterface
    {
        $selected = $this->parseAssetsString($this->request->getGet('assets'));

        return $this->response->setJSON([
            'slots' => $this->dayAssetsInternal($labId, $date, $selected)
        ]);
    }

    protected function dayAssetsInternal(int $labId, string $date, array $selected): array
    {
        if (empty($selected)) return [];

        $slotDefs = $this->getSlotDefinitions();
        $assetModel = new AssetModel();

        $assets = $assetModel->where('lab_id', $labId)
                             ->whereIn('id', array_keys($selected))
                             ->findAll();

        $assetNames = [];
        foreach ($assets as $a) {
            $assetNames[(int)$a['id']] = $a['name'];
        }

        $slots = [];
        $today = date('Y-m-d');
        $now   = date('H:i:s');

        foreach ($slotDefs as $slot) {

            $remaining = $this->computeRemainingForSlot(
                $labId, $date, $slot['start'], $slot['end'], $selected
            );

            $assetsInfo = [];
            $slotOK = true;

            foreach ($selected as $assetId => $need) {
                $rem = $remaining[$assetId] ?? 0;

                $assetsInfo[] = [
                    'id'        => $assetId,
                    'name'      => $assetNames[$assetId] ?? "Asset #$assetId",
                    'requested' => $need,
                    'remaining' => $rem,
                ];

                if ($rem < $need) $slotOK = false;
            }

            if ($date < $today || ($date === $today && $slot['end'] <= $now)) {
                $slotOK = false;
            }

            $slots[] = [
                'label'    => $slot['label'],
                'start'    => substr($slot['start'], 0, 5),
                'end'      => substr($slot['end'], 0, 5),
                'can_book' => $slotOK,
                'assets'   => $assetsInfo,
            ];
        }

        return $slots;
    }

    /*
    |--------------------------------------------------------------------------
    | AJAX CHECK SLOT
    |--------------------------------------------------------------------------
    */
    public function checkSlot(): ResponseInterface
    {
        $labId     = (int) $this->request->getPost('lab_id');
        $date      = $this->request->getPost('date');
        $startTime = $this->request->getPost('start_time');
        $endTime   = $this->request->getPost('end_time');
        $assetsRaw = $this->request->getPost('asset_selection');

        $selected = $this->parseAssetsString($assetsRaw);

        if (!$labId || !$date || !$startTime || !$endTime || empty($selected)) {
            return $this->response->setJSON([
                'conflict' => true,
                'reason' => 'Missing data or no assets selected.'
            ]);
        }

        $start = $this->normalizeTime($startTime);
        $end   = $this->normalizeTime($endTime);

        $today = date('Y-m-d');
        $now   = date('H:i:s');

        if ($date < $today || ($date === $today && $end <= $now)) {
            return $this->response->setJSON([
                'conflict' => true,
                'reason'   => 'Slot is already in the past.'
            ]);
        }

        $remaining = $this->computeRemainingForSlot(
            $labId, $date, $start, $end, $selected
        );

        foreach ($selected as $id => $need) {
            if (($remaining[$id] ?? 0) < $need) {
                return $this->response->setJSON(['conflict' => true]);
            }
        }

        return $this->response->setJSON(['conflict' => false]);
    }

    /*
    |--------------------------------------------------------------------------
    | BOOKING SUBMISSION (UTHM ONLY)
    |--------------------------------------------------------------------------
    */
    public function submit(): ResponseInterface
    {
        $validation = Services::validation();

        $rules = [
            'lab_id'            => 'required|integer',
            'date'              => 'required|valid_date[Y-m-d]',
            'start_time'        => 'required',
            'end_time'          => 'required',
            'activity'          => 'required|string',
            'applicant_faculty' => 'required',
            'pdf'               => 'uploaded[pdf]|mime_in[pdf,application/pdf]|max_size[pdf,8192]',
        ];

        if (! $this->validate($rules)) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Validation failed.',
                'errors'  => $validation->getErrors(),
            ]);
        }

        helper('auth');

        // User must be logged in
        if (! auth()->loggedIn()) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'You must log in to submit a booking.'
            ]);
        }

        $user = auth()->user();

        // Logged-in external users cannot submit bookings
        if ($user->inGroup('external')) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'External users must contact the PIC to submit bookings.'
            ]);
        }

        // At this point → UTHM user
        $userType = 'UTHM';

        $labId     = (int) $this->request->getPost('lab_id');
        $date      = $this->request->getPost('date');
        $startTime = $this->normalizeTime($this->request->getPost('start_time'));
        $endTime   = $this->normalizeTime($this->request->getPost('end_time'));
        $activity  = $this->request->getPost('activity');

        $supervisorName  = $this->request->getPost('supervisor_name');
        $supervisorEmail = $this->request->getPost('supervisor_email');
        $supervisorPhone = $this->request->getPost('supervisor_phone');

        $facultyRaw = $this->request->getPost('applicant_faculty');
        $facultyId  = is_array($facultyRaw) ? (int)$facultyRaw[0] : (int)$facultyRaw;

        // Approval flow logic
        $approvalFlow = ($facultyId === 3) ? "FKMP_APPROVAL" : "FACULTY_APPROVAL";

        // Asset parsing
        $selectedAssets = $this->parseAssetsString($this->request->getPost('asset_selection'));

        if (empty($selectedAssets)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Please select at least one asset before booking.'
            ]);
        }

        // Capacity check
        $remaining = $this->computeRemainingForSlot($labId, $date, $startTime, $endTime, $selectedAssets);

        foreach ($selectedAssets as $assetId => $qtyNeeded) {
            if (($remaining[$assetId] ?? 0) < $qtyNeeded) {
                return $this->response->setJSON([
                    'status'  => 'error',
                    'message' => 'Selected assets are not available for that slot.'
                ]);
            }
        }

        // PDF upload
        $pdfFile = $this->request->getFile('pdf');
        $pdfPath = null;

        if ($pdfFile && $pdfFile->isValid()) {
            $newName = $pdfFile->getRandomName();
            $pdfFile->move(WRITEPATH . 'uploads/pdfs', $newName);
            $pdfPath = '/uploads/pdfs/' . $newName;
        }

        $bookingModel = new BookingModel();
        $bookingAssetModel = new BookingAssetModel();

        // Insert booking
        $bookingId = $bookingModel->insert([
            'user_id'          => auth()->id(),
            'lab_id'           => $labId,
            'user_type'        => $userType,
            'faculty_id'       => $facultyId,
            'approval_flow'    => $approvalFlow,
            'date'             => $date,
            'start_time'       => $startTime,
            'end_time'         => $endTime,
            'activity'         => $activity,
            'supervisor_name'  => $supervisorName,
            'supervisor_email' => $supervisorEmail,
            'supervisor_phone' => $supervisorPhone,
            'pdf_path'         => $pdfPath,
            'status'           => 'PENDING',
        ], true);

        // Insert assets
        foreach ($selectedAssets as $assetId => $qty) {
            $bookingAssetModel->insert([
                'booking_id'    => $bookingId,
                'asset_id'      => $assetId,
                'quantity_used' => $qty,
            ]);
        }

        return $this->response->setJSON([
            'status'  => 'success',
            'message' => 'Booking submitted successfully and is pending approval.',
        ]);
    }
}
