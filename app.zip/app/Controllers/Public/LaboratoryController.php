<?php

namespace App\Controllers\Public;

use App\Controllers\BaseController;
use App\Models\LaboratoryModel;
use App\Models\AssetModel;
use App\Models\FacultyModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class LaboratoryController extends BaseController
{
    protected $laboratories;
    protected $assets;
    protected $faculties;

    public function __construct()
    {
        $this->laboratories = new LaboratoryModel();
        $this->assets       = new AssetModel();
        $this->faculties    = new FacultyModel();
        helper('auth');
    }

    /**
     * List all laboratories (public).
     */
    public function index()
    {
        $search = $this->request->getGet('q');

        if ($search) {
            $labs = $this->laboratories
                ->like('name', $search)
                ->orderBy('name', 'ASC')
                ->findAll();
        } else {
            $labs = $this->laboratories
                ->orderBy('name', 'ASC')
                ->findAll();
        }

        return view('public/laboratories/index', [
            'labs'   => $labs,
            'search' => $search,
        ]);
    }

    /**
     * Show a single laboratory with equipment + booking interface.
     */
    public function show($id = null)
    {
        $id = (int) $id;

        $lab = $this->laboratories->find($id);
        if (! $lab) {
            throw PageNotFoundException::forPageNotFound('Laboratory not found.');
        }

        $assets    = $this->assets->where('lab_id', $id)->findAll();
        $faculties = $this->faculties->getAllForDropdown();

        // Determine booking mode:
        //  - 'uthm'    → logged-in, NOT in 'external' group (students/staff)
        //  - 'external'→ logged-in external user
        //  - 'guest'   → not logged in
        $bookingMode = 'guest';

        if (function_exists('auth') && auth()->loggedIn()) {
            $user = auth()->user();

            if ($user->inGroup('external')) {
                $bookingMode = 'external';
            } else {
                $bookingMode = 'uthm';
            }
        }

        return view('public/laboratories/show', [
            'lab'         => $lab,
            'assets'      => $assets,
            'faculties'   => $faculties,
            'bookingMode' => $bookingMode,
        ]);
    }
}
