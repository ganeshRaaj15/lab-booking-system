<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ---------------------------------------------------------
// PUBLIC CONTROLLERS
// ---------------------------------------------------------
use App\Controllers\Public\HomeController;
use App\Controllers\Public\LaboratoryController;
use App\Controllers\Public\BookingController;
use App\Controllers\Public\AssetBrowseController;
use App\Controllers\Public\DocumentController;

// ---------------------------------------------------------
// DASHBOARD CONTROLLERS
// ---------------------------------------------------------
use App\Controllers\Dashboard\DashboardController;
use App\Controllers\Dashboard\StudentDashboard;
use App\Controllers\Dashboard\ExternalDashboard;
use App\Controllers\Dashboard\PicDashboard;
use App\Controllers\Dashboard\ManagerDashboard;
use App\Controllers\Dashboard\AdminDashboard;
use App\Controllers\Dashboard\ApprovalsController;

// ---------------------------------------------------------
// BOOKING APPROVAL CONTROLLER
// ---------------------------------------------------------
use App\Controllers\Approvals\BookingApprovalController;

// ---------------------------------------------------------
// ADMIN CONTROLLERS
// ---------------------------------------------------------
use App\Controllers\Admin\SettingsController;
use App\Controllers\Admin\AssetController;
use App\Controllers\Admin\LaboratoryAdminController;
use App\Controllers\Admin\UserManagementController;


// ====================================================================
// PUBLIC ROUTES (NO LOGIN REQUIRED)
// ====================================================================

$routes->get('/', [HomeController::class, 'index']);
$routes->get('/contact', [HomeController::class, 'contact']);

// Laboratories
$routes->get('/laboratories', [LaboratoryController::class, 'index']);
$routes->get('/laboratories/(:num)', [LaboratoryController::class, 'show/$1']);

// Booking APIs
$routes->get('/api/calendar/(:num)', [BookingController::class, 'calendar/$1']);
$routes->get('/api/calendar-with-assets/(:num)', [BookingController::class, 'calendarWithAssets/$1']);
$routes->get('/api/bookings/day-with-assets/(:num)/(:segment)', [BookingController::class, 'dayWithAssets/$1/$2']);

// Booking operations
$routes->post('/api/bookings/check-slot', [BookingController::class, 'checkSlot']);
$routes->post('/api/bookings/submit', [BookingController::class, 'submit']);

// Assets browsing
$routes->get('assets', [AssetBrowseController::class, 'index']);

// PDF Document viewing (with authentication)
$routes->get('document/pdf/(:segment)', [DocumentController::class, 'viewPdf/$1'], ['filter' => 'session']);

// ====================================================================
// FILE ACCESS ROUTES (FOR UPLOADED PDFS AND IMAGES) - ADD THIS
// ====================================================================

// Route to serve uploaded PDF files
$routes->get('uploads/pdfs/(:any)', function($filename) {
    $filepath = WRITEPATH . 'uploads/pdfs/' . $filename;
    
    if (!file_exists($filepath)) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException('File not found');
    }
    
    $mime = mime_content_type($filepath);
    header("Content-Type: $mime");
    header("Content-Length: " . filesize($filepath));
    
    readfile($filepath);
    exit();
});

// Optional: Route for uploaded images
$routes->get('uploads/images/(:any)', function($filename) {
    $filepath = WRITEPATH . 'uploads/images/' . $filename;
    
    if (!file_exists($filepath)) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException('File not found');
    }
    
    $mime = mime_content_type($filepath);
    header("Content-Type: $mime");
    header("Content-Length: " . filesize($filepath));
    
    readfile($filepath);
    exit();
});

// ====================================================================
// MAIN DASHBOARD ENTRY
// ====================================================================

$routes->get('dashboard', [DashboardController::class, 'index'], ['filter' => 'session']);


// ====================================================================
// DASHBOARD ROUTES (LOGIN REQUIRED)
// ====================================================================

$routes->group('dashboard', ['filter' => 'session'], function ($routes) {

    // STUDENT DASHBOARD
    $routes->get('student', [StudentDashboard::class, 'index'], ['filter' => 'group:student']);
    $routes->get('student/booking-details/(:num)', [StudentDashboard::class, 'bookingDetails/$1'], ['filter' => 'group:student']);
    $routes->post('student/cancel-booking/(:num)', [StudentDashboard::class, 'cancelBooking/$1'], ['filter' => 'group:student']);

    // EXTERNAL DASHBOARD
    $routes->get('external', [ExternalDashboard::class, 'index'], ['filter' => 'group:external']);

    // PIC DASHBOARD
    $routes->get('pic', [PicDashboard::class, 'index'], ['filter' => 'group:pic']);
    $routes->get('pic/booking/(:num)', [PicDashboard::class, 'getBookingDetails/$1'], ['filter' => 'group:pic']);

    // MANAGER DASHBOARD
    $routes->get('manager', [ManagerDashboard::class, 'index'], ['filter' => 'group:manager']);
    $routes->get('manager/booking/(:num)', [ManagerDashboard::class, 'getBookingDetails/$1'], ['filter' => 'group:manager']);

    // ADMIN DASHBOARD
    $routes->get('admin', [AdminDashboard::class, 'index'], ['filter' => 'group:admin']);

    // APPROVAL UI PAGE (accessible to PIC/MANAGER/ADMIN)
    $routes->get('approvals', [ApprovalsController::class, 'index']);
});


// ====================================================================
// BOOKING APPROVAL ROUTES (SIMPLE VERSION)
// ====================================================================

$routes->group('booking', ['filter' => 'session'], function ($routes) {
    // Combined filter - any of these groups can access
    $routes->post('approve/(:num)', [BookingApprovalController::class, 'approve/$1'], 
        ['filter' => 'group:pic,manager,admin']
    );
    
    $routes->post('reject/(:num)', [BookingApprovalController::class, 'reject/$1'], 
        ['filter' => 'group:pic,manager,admin']
    );
});


// ====================================================================
// ADMIN PANEL ROUTES (STRICTLY ADMIN ONLY)
// ====================================================================

$routes->group('admin', ['filter' => 'group:admin'], function ($routes) {

    // Settings
    $routes->get('settings', [SettingsController::class, 'index']);
    $routes->post('settings/update', [SettingsController::class, 'update']);
    $routes->post('settings/save-slots', [SettingsController::class, 'saveSlots']);

    // Laboratories CRUD
    $routes->get('labs', [LaboratoryAdminController::class, 'index']);
    $routes->get('labs/create', [LaboratoryAdminController::class, 'create']);
    $routes->post('labs/store', [LaboratoryAdminController::class, 'store']);
    $routes->get('labs/edit/(:num)', [LaboratoryAdminController::class, 'edit/$1']);
    $routes->post('labs/update/(:num)', [LaboratoryAdminController::class, 'update/$1']);
    $routes->post('labs/delete/(:num)', [LaboratoryAdminController::class, 'delete/$1']);

    // Assets CRUD - REORDERED (most specific first)
$routes->get('assets/create', [AssetController::class, 'create']);
$routes->post('assets/store', [AssetController::class, 'store']);
$routes->get('assets/edit/(:num)', [AssetController::class, 'edit/$1']);
$routes->post('assets/update/(:num)', [AssetController::class, 'update/$1']);
$routes->post('assets/delete/(:num)', [AssetController::class, 'delete/$1']);
$routes->get('assets', [AssetController::class, 'index']); // This should be LAST

    // User Management - ADD THESE TWO ROUTES:
    $routes->get('users', [UserManagementController::class, 'index']);
    $routes->get('users/create', [UserManagementController::class, 'create']);  // <-- ADD THIS
    $routes->post('users/store', [UserManagementController::class, 'store']);   // <-- ADD THIS
    $routes->get('users/edit/(:num)', [UserManagementController::class, 'edit/$1']);
    $routes->post('users/update/(:num)', [UserManagementController::class, 'update/$1']);
    $routes->post('users/delete/(:num)', [UserManagementController::class, 'delete/$1']);
});


// ====================================================================
// TEST & DEBUG ROUTES (OPTIONAL - REMOVE IN PRODUCTION)
// ====================================================================

// Debug route to test approval workflow
$routes->get('test/approve-workflow/(:num)', function($bookingId) {
    helper('auth');
    
    if (!auth()->loggedIn()) {
        return "Not logged in";
    }
    
    $user = auth()->user();
    echo "<h3>User Info:</h3>";
    echo "ID: " . $user->id . "<br>";
    echo "Email: " . $user->email . "<br>";
    echo "Groups: " . json_encode($user->getGroups()) . "<br>";
    echo "Is Manager: " . ($user->inGroup('manager') ? 'YES' : 'NO') . "<br>";
    echo "Is Admin: " . ($user->inGroup('admin') ? 'YES' : 'NO') . "<br><hr>";
    
    $db = \Config\Database::connect();
    
    // Check booking
    $booking = $db->table('bookings b')
        ->select('b.*, f.name_en, f.is_fkmp')
        ->join('faculties f', 'f.id = b.faculty_id', 'left')
        ->where('b.id', $bookingId)
        ->get()
        ->getRowArray();
    
    if (!$booking) {
        return "Booking not found";
    }
    
    echo "<h3>Booking Info:</h3>";
    foreach ($booking as $key => $value) {
        echo "$key: $value<br>";
    }
    echo "<hr>";
    
    // Test update
    echo "<h3>Test Update:</h3>";
    $testData = [
        'approved_by_manager' => 1,
        'status' => 'APPROVED',
        'updated_at' => date('Y-m-d H:i:s')
    ];
    
    $db->table('bookings')->where('id', $bookingId)->update($testData);
    
    echo "Update attempted<br>";
    
    // Check result
    $updated = $db->table('bookings')->where('id', $bookingId)->get()->getRowArray();
    echo "Approved by Manager: " . ($updated->approved_by_manager ?? 'N/A') . "<br>";
    echo "Status: " . ($updated->status ?? 'N/A') . "<br>";
    
    return "<hr><a href='/dashboard/manager'>Back to Manager Dashboard</a>";
});

// Quick route to check if user is manager
$routes->get('debug/manager', function() {
    helper('auth');
    
    if (!auth()->loggedIn()) {
        return json_encode(['error' => 'Not logged in']);
    }
    
    $user = auth()->user();
    
    return json_encode([
        'logged_in' => auth()->loggedIn(),
        'user_id' => auth()->id(),
        'email' => $user->email,
        'groups' => $user->getGroups(),
        'in_group_manager' => $user->inGroup('manager'),
        'in_group_admin' => $user->inGroup('admin'),
        'in_group_pic' => $user->inGroup('pic')
    ]);
});

// ====================================================================
// SHIELD AUTH ROUTES (MUST BE LAST)
// ====================================================================

service('auth')->routes($routes);

// Logout
$routes->post('logout', '\CodeIgniter\Shield\Controllers\LoginController::logoutAction', ['as' => 'logout']);