<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\Shield\Models\UserModel;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = new UserModel();
        $db    = \Config\Database::connect();

        $createUser = function($username, $email, $password, $group) use ($users, $db) {

            // 1. Check if email already exists in auth_identities
            $identity = $db->table('auth_identities')
                ->where('type', 'email_password')
                ->where('secret', $email)
                ->get()
                ->getFirstRow();

            if ($identity) {
                echo "Skipping existing user: {$email}\n";

                // Ensure group exists for this user
                $userId = $identity->user_id;

                $groupExists = $db->table('auth_groups_users')
                    ->where('user_id', $userId)
                    ->where('group', $group)
                    ->get()
                    ->getFirstRow();

                if (! $groupExists) {
                    $db->table('auth_groups_users')->insert([
                        'user_id'    => $userId,
                        'group'      => $group,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);
                    echo "→ Added missing group '{$group}' for {$email}\n";
                }

                return;
            }

            // 2. Create new user
            $users->insert([
                'username'   => $username,
                'active'     => 1,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $userId = $users->getInsertID();

            // 3. Create identity record
            $db->table('auth_identities')->insert([
                'user_id'    => $userId,
                'type'       => 'email_password',
                'secret'     => $email,
                'secret2'    => password_hash($password, PASSWORD_DEFAULT),
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // 4. Assign group
            $db->table('auth_groups_users')->insert([
                'user_id'    => $userId,
                'group'      => $group,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            echo "Created {$group} user: {$email}\n";
        };

        // =========================
        // SYSTEM USERS
        // =========================
        $createUser('admin', 'admin@fkmp.uthm.edu.my', 'Admin@12345', 'admin');
        $createUser('piclab01', 'pic.lab01@fkmp.uthm.edu.my', 'Pic@12345', 'pic');

        // NEW MANAGER ACCOUNT
        $createUser('manager01', 'manager01@fkmp.uthm.edu.my', 'Manager@12345', 'manager');

        $createUser('tech01', 'tech01@fkmp.uthm.edu.my', 'Tech@12345', 'technician');
        $createUser('staff01', 'staff01@fkmp.uthm.edu.my', 'Staff@12345', 'staff');
        $createUser('d1230042', 'd1230042@student.uthm.edu.my', 'Student@12345', 'student');
        $createUser('external01', 'external01@example.com', 'External@12345', 'external');

        echo "User seeding completed.\n";
    }
}
